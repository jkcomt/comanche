    

<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('clientes.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('clientes.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <a href="<?php echo e(route('clientes.nuevo')); ?>" class="btn btn-success">NUEVO CLIENTE</a>
            </div>
        </div>
        <div class="col-md-10">
            <form action="" class="form-inline">
                <input type="text" placeholder="BUSCAR..." class="form-control">
                <button class="btn btn-primary form-control">BUSCAR</button>
            </form>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <table class="table table-hover table-condensed">
                <thead>
                <th>NOMBRES</th>
                <th>DNI</th>
                <th>CELULAR</th>
                <th>ACCIONES</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cliente->apellidos.' '.$cliente->nombres); ?></td>
                        <td><?php echo e($cliente->dni); ?></td>
                        <td><?php echo e($cliente->celular); ?></td>
                        <td>
                            <a href="#" class="btn btn-xs btn-info "><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                            <a href="#" class="btn btn-xs btn-warning edit"  value="<?php echo e($cliente->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                            <?php echo e(csrf_field()); ?>

                            <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($cliente->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($cliente->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/clientes.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
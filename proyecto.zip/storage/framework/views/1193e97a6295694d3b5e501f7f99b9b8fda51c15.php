<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N° GUÍA ING.</th>
        <th>FECHA INGRESO</th>
        <th>N° GUÍA</th>
        <th>AGRICULTOR\EMPRESA</th>
        <th>ORIGEN</th>
        <th>ESTADO</th>
        <th>CONFORME</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $produccionIngresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produccionIngreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($produccionIngreso->estado == 'Habilitado'): ?>
            <tr>
                <td><?php echo e($produccionIngreso->nro_guia_ingreso); ?></td>
                <td><?php echo e($produccionIngreso->fecha); ?> <?php echo e(Carbon\Carbon::parse($produccionIngreso->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($produccionIngreso->lote->nro_guia); ?></td>
                <?php if($produccionIngreso->lote->agricultor): ?>
                    <td><?php echo e($produccionIngreso->lote->agricultor->apellidos); ?> <?php echo e($produccionIngreso->lote->agricultor->nombres); ?></td>
                <?php elseif($produccionIngreso->lote->empresa): ?>
                    <td><?php echo e($produccionIngreso->lote->empresa->razon_social); ?></td>
                <?php endif; ?>
                <td><?php echo e($produccionIngreso->area_origen); ?></td>
                <td>
                    <?php if($produccionIngreso->estado_prod_ingreso == 'terminado'): ?>
                        <span style="font-size: 10px;" class="   label label-success "><?php echo e(ucwords($produccionIngreso->estado_prod_ingreso)); ?></span>
                    <?php else: ?>
                        <?php if($produccionIngreso->nuevaProduccion->first()): ?>
                            <span style="font-size: 10px;" class="label label-warning"><?php echo e(ucwords($produccionIngreso->estado_prod_ingreso)); ?></span>
                        <?php else: ?>
                            <span style="font-size: 10px; background-color:yellow !important; color: #000 !important;" class="label label-warning">Aperturado</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($produccionIngreso->estado_prod_ingreso == 'terminado'): ?>
                        <a href="#" produccion="<?php echo e($produccionIngreso->id); ?>" class="btn btn-xs btn-primary
                          <?php if($produccionIngreso->conforme): ?>
                            <?php else: ?>
                                conformidad
                          <?php endif; ?>" <?php if($produccionIngreso->conforme): ?> disabled <?php endif; ?>
                        ><?php if($produccionIngreso->conforme): ?> SI <?php else: ?> NO <?php endif; ?></a>
                    <?php else: ?>
                        <span style="font-size: 10px;" class="label label-warning"><?php echo e(ucwords("En proceso")); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($produccionIngreso->lote->id); ?>" id="<?php echo e($produccionIngreso->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('produccion.reporte',$produccionIngreso->id)); ?>" target="_blank" class="btn btn-xs btn-info
                    <?php if($produccionIngreso->estado_prod_ingreso == 'terminado'): ?>
                    <?php else: ?>
                        disabled
                    <?php endif; ?>
                    "><span class="glyphicon glyphicon-print"></span> IMP.</a>
                    <?php echo e(csrf_field()); ?>

                    <a href="<?php echo e(route('nuevaproduccion.index',['id'=>$produccionIngreso->id])); ?>" class="btn btn-xs btn-success
                    <?php if(!$produccionIngreso->validarDetallesRegistrosAnteriores()): ?>
                        disabled
                    <?php endif; ?>
                    "><span class="glyphicon glyphicon-plus"></span> NUEVA PRODUCCION</a>
                </td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($produccionIngresos->links()); ?>

</div>

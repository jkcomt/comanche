<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N° GUÍA SALIDA</th>
        <th>FECHA</th>
        <th>STOCK INICIAL</th>
        <th>Nro. SACOS POR PROCESAR</th>
        <th>Nro. SACOS SALDO A PROCESAR</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $nuevaProducciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nuevaProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($nuevaProduccion->estado): ?>
            <tr>
                <td><?php echo e($nuevaProduccion->nro_guia_salida); ?></td>
                <td><?php echo e($nuevaProduccion->fecha.' '.Carbon\Carbon::parse($nuevaProduccion->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($nuevaProduccion->nro_sacos_stock_inicial); ?></td>
                <td><?php echo e($nuevaProduccion->nro_sacos_a_procesar); ?></td>
                <td><?php echo e($nuevaProduccion->nro_sacos_saldo); ?></td>
                <td>
                    <?php
                        $idAnterior = $nuevaProduccion->ingresoProduccion->nuevaProduccion->where('estado','Habilitado')->last()->id
                    ?>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($nuevaProduccion->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('nuevaproduccion.reporte',$nuevaProduccion->id)); ?>" target="_blank" class="btn btn-xs btn-info"><span class="glyphicon glyphicon-print" ></span> IMP.</a>

                    <?php if(auth()->user()->area->descripcion == "administrador"): ?>
                    <a href="<?php echo e(route('nuevaproduccion.edit',$nuevaProduccion->id)); ?>" class="btn btn-xs btn-warning edit
                    <?php if($nuevaProduccion->id != $idAnterior): ?>
                            disabled
                    <?php endif; ?>
                    "  value="<?php echo e($nuevaProduccion->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                    <?php echo e(csrf_field()); ?>


                    
                    <a href="#" class="btn btn-xs btn-danger delete
                    <?php if($nuevaProduccion->id != $idAnterior): ?>
                            disabled
                    <?php endif; ?>
                        "  id="<?php echo e($nuevaProduccion->id); ?>"><span class="glyphicon glyphicon-remove" ></span> ELIM.</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($nuevaProducciones->links()); ?>

</div>
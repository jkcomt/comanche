<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-hover table-condensed box">
        <thead>
        <th>NOMBRES Y APELLIDOS</th>
        <th>DNI</th>
        <th>CELULAR</th>
        <th>DIRECCIÓN</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chofer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($chofer->nombres.' '.$chofer->apellidos); ?></td>
                <td><?php echo e($chofer->dni); ?></td>
                <td><?php echo e($chofer->celular); ?></td>
                <td><?php echo e($chofer->direccion); ?></td>
                <td>
                    
                    <a href="#" class="btn btn-xs btn-warning edit"  value="<?php echo e($chofer->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                    <?php echo e(csrf_field()); ?>

                    <?php if(auth()->user()->area->descripcion == 'administrador'): ?>
                    <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($chofer->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($choferes->links()); ?>

</div>
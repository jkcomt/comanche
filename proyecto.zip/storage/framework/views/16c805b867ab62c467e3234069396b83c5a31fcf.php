<a href="#" class="dropdown-toggle" data-toggle="dropdown">
    <span class="glyphicon glyphicon-bell"></span>
    <span class="hidden-xs">Notificaciones</span>
    <?php if(count(auth()->user()->unreadNotifications) > 0): ?>
        <span class="badge"><?php echo e(count(auth()->user()->unreadNotifications)); ?></span>
        <span class="caret"></span>
    <?php endif; ?>
</a>

<ul class="dropdown-menu" role="menu">
    <?php if(count(auth()->user()->unreadNotifications) > 0): ?>

        <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('secado.markasread',['id'=>$notification->id])); ?>" class="btn btn-flat btn-success btn-block ">Nuevo lote enviado : <?php echo e($notification->data['lote']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <span class="btn btn-flat btn-block btn-primary">No hay notificaciones</span>
    <?php endif; ?>
</ul>


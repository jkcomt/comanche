<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>CAMPAÑA</th>
        <th>FECHA</th>
        <th>N° GUÍA</th>
        <th>AGRICULTOR\CLIENTE</th>
        <th>VARIEDAD</th>
        <th>N° SACOS</th>
        <th>CONFORME</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($lote->compania); ?></td>
                <td><?php echo e($lote->fecha); ?> <?php echo e(Carbon\Carbon::parse($lote->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($lote->nro_guia); ?></td>
                <?php if($lote->cliente): ?>
                    <td><?php echo e($lote->cliente->apellidos); ?> <?php echo e($lote->cliente->nombres); ?></td>
                <?php elseif($lote->agricultor): ?>
                    <td><?php echo e($lote->agricultor->apellidos); ?> <?php echo e($lote->agricultor->nombres); ?></td>
                <?php endif; ?>
                <td><?php echo e($lote->variedad->descripcion); ?></td>
                <td><?php echo e($lote->nro_sacos); ?></td>
                <td>
                    <a href="#" class="btn btn-xs btn-primary <?php if($lote->conforme): ?>  <?php else: ?> conformidad <?php endif; ?>" lote="<?php echo e($lote->id); ?>" <?php if($lote->conforme): ?> disabled <?php endif; ?>><?php if($lote->conforme): ?> SI <?php else: ?> NO <?php endif; ?></a>
                </td>
                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($lote->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('lote.reporte',$lote->id)); ?>" target="_blank" class="btn btn-xs btn-info "><span class="glyphicon glyphicon-print"></span> IMP.</a>
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-xs btn-danger <?php if($lote->conforme): ?>  <?php elseif($lote->ultimoLote()->id > $lote->id): ?> <?php else: ?> delete <?php endif; ?>"  id="<?php echo e($lote->id); ?>"  <?php if($lote->conforme): ?> disabled  <?php elseif($lote->ultimoLote()->id > $lote->id): ?> disabled <?php endif; ?>><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($lotes->links()); ?>

</div>
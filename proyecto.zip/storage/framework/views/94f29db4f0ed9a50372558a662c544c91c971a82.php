<div class="col-lg-12 col-md-12 col-sm-12" >
    <table class="table table-hover table-condensed box ">
        <thead>
        <th>APE. Y NOMBRES</th>
        <th>DNI</th>
        <th>RUC</th>
        <th>CELULAR</th>
        <th>DIRECCIÓN</th>
        <th>EMAIL</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $compradorPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compradorPersona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($compradorPersona->estado == 'Habilitado'): ?>
            <tr>
                <td><?php echo e($compradorPersona->apellidos.' '.$compradorPersona->nombres); ?></td>
                <td><?php echo e($compradorPersona->dni); ?></td>
                <td><?php echo e($compradorPersona->ruc); ?></td>
                <td><?php echo e($compradorPersona->celular); ?></td>
                <td><?php echo e($compradorPersona->direccion); ?></td>
                <td><?php echo e($compradorPersona->email); ?></td>
                <td>
                    
                    <button class="btn btn-xs btn-warning edit"  value="<?php echo e($compradorPersona->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</button>
                    <?php echo e(csrf_field()); ?>

                    <?php if(auth()->user()->area->descripcion == 'administrador'): ?>
                    <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($compradorPersona->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($compradorPersonas->links()); ?>

</div>
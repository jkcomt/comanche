<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>COD PRODUCTO</th>
        <th>DESCRIPCIÓN</th>
        <th>SALDO DISPONIBLE</th>
        <th>KILOS</th>
        <th>PRECIO</th>
        <th>ESTADO</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $stockProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                <tr>
                    <td>
                        <?php echo e($stockProducto->serie_producto); ?>

                    </td>
                    <td>
                        <?php echo e($stockProducto->descripcion_producto); ?>

                    </td>
                    <td>
                        <?php if($stockProducto->cantidad_stock): ?>
                            <?php echo e($stockProducto->cantidad_stock); ?>

                            <?php else: ?>
                            0
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($stockProducto->kilos); ?>

                    </td>
                    <td>
                        <?php echo e($stockProducto->precio); ?>

                    </td>
                    <td>
                        <?php if($stockProducto->cantidad_stock): ?>
                            <?php if($stockProducto->cantidad_stock > 0): ?>
                                DISPONIBLE
                            <?php else: ?>
                                NO DISPONIBLE
                            <?php endif; ?>
                            <?php else: ?>
                            NO DISPONIBLE
                        <?php endif; ?>


                    </td>
                    <td>

                        <button class="btn btn-xs btn-primary cambiarPrecio
                            <?php if($stockProducto->cantidad_stock == 0): ?>
                                    disabled
                            <?php endif; ?>" id="<?php echo e($stockProducto->stock_producto_id); ?>">INGRESAR PRECIO</button>
                    </td>
                </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</div>
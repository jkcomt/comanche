
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Sistema Comanche</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo e(asset('css/ie10-viewport-bug-workaround.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    

    

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="<?php echo e(asset('js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <script src="<?php echo e(asset('js/ie-emulation-modes-warning.js')); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body{
            font-size: 12px;
        }
        .center-text{
            text-align: center;
        }
        .padding-top{
            padding-top: 30px;
            border: hidden;
        }

    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <table>
            <tr>
                <td style="padding-right: 100px">
                    <h5>MOLINO EL COMANCHE S.R.L.</h5>
                    
                    <h5>RUC: 20482126112  |  Cel: 972620212  |  Teléfono:044-498067</h5>
                </td >
                <td style="margin-left:50px;padding-left: 150px"><img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="120px" height="100px"></td>
            </tr>
        </table>
    </div>
<hr>
    <div class="">
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                <td>Campaña</td>
                <td>Nro. Guía</td>
                <td>Fecha - Hora</td>
                <td>
                <?php if(!empty($lote->agricultor)): ?>
                    Agricultor
                <?php else: ?>
                    Cliente
                <?php endif; ?>
                </td>
                </tr>
                <tr>
                    <td>
                    <?php echo e($lote->compania); ?>

                    </td>
                    <td><?php echo e($lote->nro_guia); ?>

                    </td>
                    <td>
                       <?php echo e($lote->fecha.' '.Carbon\Carbon::parse($lote->hora)->format('H:i:s A')); ?>

                    </td>
                    <td>
                       <?php if(!empty($lote->agricultor)): ?>
                           <?php echo e($lote->agricultor->apellidos.' '.$lote->agricultor->nombres); ?>

                       <?php else: ?>
                           <?php echo e($lote->cliente->apellidos.' '.$lote->cliente->nombres); ?>

                       <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                  <td>Variedad</td>
                   <td>Tipo peso</td>
                   <td>
                    <?php if($lote->tipo_peso == 'sacos'): ?>
                       Nro. Sacos
                    <?php elseif($lote->tipo_peso == 'kilos'): ?>
                       Peso Real(Kg)
                    <?php endif; ?>
                    </td>
                    <td>
                      <?php if($lote->tipo_peso == 'sacos'): ?>
                        Kilos
                      <?php elseif($lote->tipo_peso == 'kilos'): ?>
                        Nro. Sacos
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($lote->tipo_peso == 'sacos'): ?>
                        Peso Real(Kg)
                      <?php elseif($lote->tipo_peso == 'kilos'): ?>
                         Kilos
                      <?php endif; ?>
                     </td>
                    </tr>
                    <tr>
                        <td>
                            <?php echo e($lote->variedad->descripcion); ?>

                        </td>
                        <td>
                            <?php echo e(ucfirst($lote->tipo_peso)); ?>

                        </td>
                        <td>
                            <?php if($lote->tipo_peso == 'sacos'): ?>
                                <?php echo e($lote->nro_sacos); ?>

                            <?php elseif($lote->tipo_peso == 'kilos'): ?>
                                <?php echo e($lote->peso_real); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($lote->tipo_peso == 'sacos'): ?>
                                <?php echo e($lote->kilos); ?>

                            <?php elseif($lote->tipo_peso == 'kilos'): ?>
                                <?php echo e($lote->nro_sacos); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($lote->tipo_peso == 'sacos'): ?>
                                <?php echo e($lote->peso_real); ?>

                            <?php elseif($lote->tipo_peso == 'kilos'): ?>
                                <?php echo e($lote->kilos); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Origen</td>
                    <td>Tipo flete</td>
                    <td>
                        Pagado por
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($lote->procedencia->lugar); ?>

                    </td>
                    <td>
                        <?php if($lote->tipo_flete == 'fletePeso'): ?>
                            Peso
                        <?php elseif($lote->tipo_flete == 'fleteSaco'): ?>
                            Saco
                        <?php elseif($lote->tipo_flete == 'fleteTonelada'): ?>
                            Tonelada
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e(ucfirst($lote->pagado_por)); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Flete x Saco</td>
                    <td>Flete x Peso</td>
                    <td>Flete x Tonelada</td>
                    <td>Flete Total</td>
                </tr>
                <tr>
                    <td>
                       S/ <?php echo e($lote->flete_x_saco); ?>

                    </td>
                    <td>
                       S/ <?php echo e($lote->flete_x_peso); ?>

                    </td>
                    <td>
                       S/  <?php echo e($lote->flete_x_tonelada); ?>

                    </td>
                    <td>
                       S/  <?php echo e($lote->flete_total); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Chofer</td>
                    <td>Vehículo</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($lote->chofer->apellidos.' '.$lote->chofer->nombres); ?>

                    </td>
                    <td>
                        <?php echo e($lote->vehiculo->marca.' '.$lote->vehiculo->descripcion.' '.$lote->vehiculo->placa); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Nro Sacos % humedad mayor a 13 </td>
                    <td>Condición</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($lote->nro_humedad_mayor_13); ?>

                    </td>
                    <td>
                        <?php if($lote->nro_humedad_mayor_13 > 0): ?> Secado <?php else: ?> Vacío <?php endif; ?>
                    </td>
                </tr>

            </table>
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Nro Sacos % humedad menor e igual a 13 </td>
                    <td>Condición</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($lote->nro_humedad_menor_13); ?>

                    </td>
                    <td>
                        <?php if($lote->nro_humedad_menor_13 > 0): ?> Producción <?php else: ?> Vacío <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
        <table class="table table-condensed table-bordered">
            <tr>
            <td >Observación:</td>
            </tr>
            <tr>
                <td style="font-size: 9px;"><?php echo e($lote->observacion); ?></td>
            </tr>
        </table>
        <table class="table padding-top">
            <tr class="center-text" >
                <td >
                <b>___________________________________</b><br>
                <b>Jefe de Recepción</b><br>
                <b><?php echo e(auth()->user()->personal->apellidos.' '.auth()->user()->personal->nombres); ?></b>
                </td>
                <td>

                </td>
                <td>
                    <b>___________________________________</b><br>
                    <?php if(!empty($lote->agricultor)): ?>
                        <b>Agricultor :</b>
                        <b><?php echo e($lote->agricultor->apellidos.' '.$lote->agricultor->nombres); ?></b><br>
                        <b><?php echo e($lote->agricultor->dni); ?></b>
                    <?php else: ?>
                        <b>Cliente :</b>
                        <b><?php echo e($lote->cliente->apellidos.' '.$lote->cliente->nombres); ?></b><br>
                        <b><?php echo e($lote->cliente->dni); ?></b>
                    <?php endif; ?>
                </td>
            </tr>
            
                
            

        </table>
    </div>
</div>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
</body>
</html>

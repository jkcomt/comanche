<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE RECOJOS DE '.$tendido->nro_guia_tendido ); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('recojo.modals.detalle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-1">
            <a class="btn btn-warning" href="<?php echo e(route('tendido.index',['id'=>$tendido->loteSecado->id])); ?>">Volver</a>
        </div>
        <div class="col-md-2">
            <div class="form-group form-inline">
                <a href="<?php if($tendido->ultimoNroSacosNoRecogidos()): ?> # <?php else: ?> <?php echo e(route('recojo.nuevo',['id'=>$tendido->id])); ?> <?php endif; ?>" class="btn btn-success" <?php if($tendido->ultimoNroSacosNoRecogidos()): ?> disabled <?php endif; ?>>NUEVO RECOJO</a>
            </div>
        </div>
        <div class="col-md-9">
            <form action="" class="form-inline text-right">
                <label for="">Nro. Guía</label>
                <input type="text" placeholder="BUSCAR..." class="form-control" id="buscarRecojo">
                <input type="hidden" name="idtendido" value="<?php echo e($tendido->id); ?>">
                
            </form>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-body">
                <strong><p style="font-size: 15px;">Nro Sacos Tendidos: <?php echo e($tendido->nro_sacos_a_secar); ?></p></strong>
                <?php if(isset($tendido->recojo->where('estado','Habilitado')->last()->nro_sacos_no_recogidos)): ?>
                    <?php if($tendido->recojo->where('estado','Habilitado')->last()->nro_sacos_no_recogidos <= 0): ?>
                        <?php if($tendido->recojo->where('estado','Habilitado')->sum('nro_sacos_recogidos') < $tendido->nro_sacos_a_secar): ?>
                            <strong><p style="font-size: 15px;">Hay una pérdida de <?php echo e($tendido->nro_sacos_a_secar - $tendido->recojo->where('estado','Habilitado')->sum('nro_sacos_recogidos')); ?> sacos</p></strong>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row" id="tabla">
        <?php echo $__env->make('recojo.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/recojo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
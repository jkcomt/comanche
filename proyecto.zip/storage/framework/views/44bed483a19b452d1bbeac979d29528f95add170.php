<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N° GUÍA</th>
        <th>FECHA</th>
        <th>Nro SACOS RECOGIDOS</th>
        <th>KG RECOGIDOS</th>
        <th>PESO RECOGIDO</th>
        <th>Nro SACOS NO RECOGIDOS</th>
        <th>KG NO RECOGIDOS</th>
        <th>PESO NO RECOGIDO</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $recojos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recojo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($recojo->nro_guia_recojo); ?></td>
                <td><?php echo e($recojo->fecha.' '.Carbon\Carbon::parse($recojo->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($recojo->nro_sacos_recogidos); ?></td>
                <td><?php echo e($recojo->kilos_recogidos); ?></td>
                <td><?php echo e($recojo->peso_recogidos); ?></td>
                <td><?php echo e($recojo->nro_sacos_no_recogidos); ?></td>
                <td><?php echo e($recojo->kilos_no_recogidos); ?></td>
                <td><?php echo e($recojo->peso_no_recogido); ?></td>
                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($recojo->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('recojo.reporte',$recojo->id)); ?>" target="_blank" class="btn btn-xs btn-info "><span class="glyphicon glyphicon-print" ></span> IMP.</a>
                    
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-xs btn-danger <?php if($recojo->ultimoRecojo()->id > $recojo->id): ?> <?php else: ?> delete <?php endif; ?>"  id="<?php echo e($recojo->id); ?>" <?php if($recojo->ultimoRecojo()->id > $recojo->id): ?> disabled <?php endif; ?> ><span class="glyphicon glyphicon-remove" ></span> ELIM.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($recojos)): ?>
            <tr>
                <td></td>
                <td><strong>Total :</strong></td>
                <td><strong><?php echo e($recojos->sum('nro_sacos_recogidos')); ?></strong></td>
                <td><strong><?php echo e($recojos->sum('kilos_recogidos')); ?></strong></td>
                <td><strong><?php echo e(($recojos->sum('peso_recogidos'))); ?></strong></td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($recojos->links()); ?>

</div>
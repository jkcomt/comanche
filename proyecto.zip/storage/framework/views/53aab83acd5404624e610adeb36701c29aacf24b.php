<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N° GUÍA</th>
        <th>FECHA</th>
        <th>RESPONSABLE</th>
        <th>Nro. SACOS TENDIDOS</th>
        <th>Nro. SACOS NO SECADOS</th>
        <th>Nro. SACOS PERDIDOS</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tendidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tendido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tendido->nro_guia_tendido); ?></td>
                <td><?php echo e($tendido->fecha.' '.Carbon\Carbon::parse($tendido->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($tendido->responsable->apellidos.' '.$tendido->responsable->nombres); ?></td>
                <td><?php echo e($tendido->nro_sacos_a_secar); ?></td>
                <td><?php echo e($tendido->nro_sacos_no_secado); ?></td>
                <td><?php if($tendido->recojo->last()): ?><?php if($tendido->recojo->last()->nro_sacos_no_recogidos == 0): ?><?php echo e($tendido->nro_sacos_a_secar - $tendido->recojo->where('estado','Habilitado')->sum('nro_sacos_recogidos')); ?><?php endif; ?> <?php else: ?> 0 <?php endif; ?></td>
                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($tendido->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('tendido.reporte',$tendido->id)); ?>" target="_blank" class="btn btn-xs btn-info "><span class="glyphicon glyphicon-print" ></span> IMP.</a>
                    
                    <?php echo e(csrf_field()); ?>

                    <a href="<?php echo e(route('recojo.index',['id'=>$tendido->id])); ?>" class="btn btn-xs btn-success recojo"><span class="glyphicon glyphicon-plus" ></span> LISTA DE RECOJOS</a>
                    <a href="#" class="btn btn-xs btn-danger <?php if($tendido->loteSecado->ultimoTendido()->id > $tendido->id): ?> # <?php elseif($tendido->ultimoNroSacosNoRecogidos()): ?> # <?php else: ?> delete <?php endif; ?>"  id="<?php echo e($tendido->id); ?>" <?php if($tendido->loteSecado->ultimoTendido()->id > $tendido->id): ?> disabled <?php elseif($tendido->ultimoNroSacosNoRecogidos()): ?> disabled <?php endif; ?>><span class="glyphicon glyphicon-remove" ></span> ELIM.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($tendidos->links()); ?>

</div>
<?php $__env->startSection('api'); ?>
    <?php echo $__env->make('apis.select2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('tendido.index',['id'=>$loteSecado->id])); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('responsables.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header','Nuevo Tendido'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
                <div id="msg-error" class="alert alert-danger" style="display:none;">
                    <strong>Corriga los campos indicados por favor.</strong>
                    <ul>
                    <div id="listaerrores">
                    </div>
                    </ul>
                    
                    
                        
                    
                    
                </div>
            <div class="panel panel-default">
                    <div class="panel-heading">INFORMACIÓN DE RECEPCIÓN DE LOTES INGRESANTES</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="">
                            <div class="col-md-2 form-group">
                                <label for="">Campaña:</label>
                                <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->compania); ?>" readonly>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">Nro. Guía de Ingreso:</label>
                                <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->nro_guia); ?>" readonly>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">Fecha - Hora:</label>
                                <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->fecha.' - '.$loteSecado->lote->hora); ?>" readonly>
                            </div>
                                <div class="col-md-3">
                                    <?php if(!empty($loteSecado->lote->agricultor)): ?>
                                        <label for="">Agricultor:</label>
                                    <input type="text" class="form-control" value="<?php echo e($loteSecado->lote->agricultor->apellidos.' '.$loteSecado->lote->agricultor->nombres); ?>" readonly>
                                <?php else: ?>
                                    <label for="">Cliente</label>
                                    <input type="text" class="form-control" value="<?php echo e($loteSecado->lote->cliente->apellidos.' '.$loteSecado->lote->cliente->nombres); ?>" readonly>
                                <?php endif; ?>
                            </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-2">
                                <label for="">Tipo de Peso:</label>
                                <?php if($loteSecado->lote->tipo_peso == 'sacos'): ?>
                                    <div class="center-block">
                                        Sacos
                                    </div>
                                <?php elseif($loteSecado->lote->tipo_peso == 'kilos'): ?>
                                    <div class="center-block">
                                        Kilos
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if($loteSecado->lote->tipo_peso == 'sacos'): ?>
                                <div class="col-md-2">
                                    <label for="">Nro. Sacos:</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->nro_sacos); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Kilos:</label>
                                    <input type="text" name="lote_kilos" class="form-control" value="<?php echo e($loteSecado->lote->kilos); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Peso Real (Kg):</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->peso_real); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Variedad:</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->variedad->descripcion); ?>" readonly>
                                </div>
                            <?php elseif($loteSecado->lote->tipo_peso == 'kilos'): ?>
                                <div class="col-md-2">
                                    <label for="">Peso Real (Kg):</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->peso_real); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Nro. Sacos:</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->nro_sacos); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Kilos:</label>
                                    <input type="text" name="lote_kilos" class="form-control" value="<?php echo e($loteSecado->lote->kilos); ?>" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label for="">Variedad:</label>
                                    <input type="text" name="" class="form-control" value="<?php echo e($loteSecado->lote->variedad->descripcion); ?>" readonly>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">INFORMACIÓN DE TENDIDO</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('tendido.create')); ?>" id="registrarTendido">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <input type="hidden" name="lote_secado" value="<?php echo e(($loteSecado->id)); ?>">
                                <label for="nro_guia_tendido" >Nro. Guía de Tendido:</label>
                                <input type="text" name="nro_guia_tendido" class="form-control" readonly value="<?php if(isset($tendido)): ?><?php echo e($tendido->generarSerieGuia()); ?><?php else: ?><?php echo e("TEN-000001"); ?><?php endif; ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="fecha">Fecha - Hora:</label>
                                <div class="form-inline">
                                    <div class="form-group">
                                        <input type="date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>" class="form-control" name="fecha">
                                        <input type="time" value="<?php echo e(\Carbon\Carbon::now()->toTimeString()); ?>" class="form-control" name="hora">
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="responsable" class="control-label">Responsable de cuadrilla:</label>
                                <div class="input-group" id="responsableGroup">
                                    <select name="responsable" id="responsable" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($responsable); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addResponsable"><span class="glyphicon glyphicon-plus"></span></a>
                                        <button class="btn btn-warning" type="button" id="reloadResponsable" url="<?php echo e(route('tendido.responsables')); ?>"><span class="glyphicon glyphicon-refresh"></span></button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="">Nro Sacos Por Secar:</label>
                                        <input type="text" class="form-control" name="sacos_pendientes" value="<?php if($loteSecado->tendido->where('estado','Habilitado')->isEmpty()): ?> <?php echo e($loteSecado->lote->nro_humedad_mayor_13); ?> <?php else: ?> <?php echo e($tendido->nro_sacos_no_secado); ?> <?php endif; ?>" readonly>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="">Kilos Por Secar:</label>
                                        <input type="number" step="any" value="0" name="kilos_pendientes" class="form-control" readonly>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="sacos_secar" class="control-label">Nro Sacos a Secar:</label>
                                        <input type="number" step="any" value="0" name="sacos_secar" class="form-control" min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="kilos_secar">Kilos a Secar:</label>
                                        <input type="number" step="any" value="0" name="kilos_secar" class="form-control" min="0" max="200" readonly>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="sacos_restantes">Nro Sacos Restantes:</label>
                                        <input type="number" step="any" value="0" name="sacos_restantes" class="form-control" min="0" readonly>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="kilos_restantes">Kilos Restantes:</label>
                                        <input type="number" step="any" value="0" name="kilos_restantes" class="form-control" min="0" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="">Observación:</label>
                                <textarea name="observacion" id="" cols="30" rows="11" class="form-control"></textarea>
                            </div>

                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success">Registrar</button>
                                <a href="<?php echo e(route('tendido.index',['id'=>$loteSecado->id])); ?>" class="btn btn-warning">Volver</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/tendido.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="col-lg-12 col-md-12 col-sm-12" >
    <table class="table table-hover table-condensed box ">
        <thead>
        <th>RAZON SOCIAL</th>
        <th>RUC</th>
        <th>DIRECCIÓN</th>
        <th>TELÉFONO</th>
        <th>EMAIL</th>
        <th>REPRESENTANTE</th>
        <th>DNI</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($empresa->estado == 'Habilitado'): ?>
            <tr>
                <td><?php echo e($empresa->razon_social); ?></td>
                <td><?php echo e($empresa->ruc); ?></td>
                <td><?php echo e(substr($empresa->direccion,0,30)); ?>...</td>
                <td><?php echo e($empresa->telefono); ?></td>
                <td><?php echo e($empresa->email); ?></td>
                <td><?php echo e($empresa->representante); ?></td>
                <td><?php echo e($empresa->dni_representante); ?></td>
                <td>
                    
                    <button class="btn btn-xs btn-warning edit"  value="<?php echo e($empresa->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</button>
                    <?php echo e(csrf_field()); ?>

                    <?php if(auth()->user()->area->descripcion == 'administrador'): ?>
                        <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($empresa->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($empresas->links()); ?>

</div>
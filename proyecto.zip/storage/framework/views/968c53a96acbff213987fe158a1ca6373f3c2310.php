
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Sistema Comanche</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo e(asset('css/ie10-viewport-bug-workaround.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->




<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="<?php echo e(asset('js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <script src="<?php echo e(asset('js/ie-emulation-modes-warning.js')); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body{
            font-size: 12px;
        }
        .center-text{
            text-align: center;
        }
        .padding-top{
            padding-top: 30px;
            border: hidden;
        }

    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <table>
            <tr>
                <td style="padding-right: 100px">
                    <h5>MOLINO EL COMANCHE S.R.L.</h5>
                    <h5>Carretera Panamericana Norte Km. 690 Centro Poblado Menor San Martín de Porres – San José – Provincia de Pacasmayo – La Libertad.</h5>
                    <h5>RUC: 20482126112  |  Cel: 972620212  |  Teléfono:044-498067</h5>
                </td >
                <td>
                    
                    <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="120px" height="100px">
                </td>
            </tr>
        </table>
    </div>
    <hr>
    <div class="text-center">
        <h3 style="margin-top:5px;">DOCUMENTO DE VENTAS</h3>
    </div>
    <div class="">
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td><label for="">Guía Prod:</label></td>
                    <td><label for="">Fecha - Hora</label></td>
                    <?php if($venta->tipo_cliente == "persona"): ?>
                        <td><label for="">Persona</label></td>
                    <?php elseif($venta->tipo_cliente == "empresa"): ?>
                        <td><label for="">Empresa</label></td>
                    <?php endif; ?>

                </tr>
                <tr>
                    <td><?php echo e($venta->nro_guia_venta); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($venta->fecha_venta)->toDateString().' '.\Carbon\Carbon::parse($venta->hora_venta)->toTimeString()); ?></td>
                    <?php if($venta->tipo_cliente == "persona"): ?>
                        <td><?php echo e($venta->compradorPersona->apellidos.' '.$venta->compradorPersona->nombres); ?></td>
                        <?php elseif($venta->tipo_cliente == "empresa"): ?>
                        <td><?php echo e($venta->compradorEmpresa->razon_social); ?></td>
                    <?php endif; ?>
                </tr>
            </table>
            <table class="table table-condensed table-bordered">
                <tr>
                    <td><label for="">Comprobante:</label></td>
                    <td><label for="">Nro. Comprobante</label></td>
                </tr>
                <tr>
                    <td><?php echo e($venta->tipo_comprobante); ?></td>
                    <?php if($venta->tipo_comprobante == "BOLETA"): ?>
                        <td><?php echo e($venta->nro_boleta); ?></td>
                    <?php elseif($venta->tipo_comprobante == "FACTURA"): ?>
                        <td><?php echo e($venta->nro_factura); ?></td>
                    <?php elseif($venta->tipo_comprobante == "TICKET"): ?>
                        <td><?php echo e($venta->nro_ticket); ?></td>
                    <?php endif; ?>
                </tr>
            </table>
        </div>

        <hr>
        <table class="table table-condensed table-bordered">
            <tr>
                <td><label for="">COD. PRODUCTO:</label></td>
                <td><label for="">DESCRIPCION PRODUCTO</label></td>
                <td><label for="">CANTIDAD</label></td>
                <td><label for="">KILOS</label></td>
                <td><label for="">PRECIO</label></td>
                <td><label for="">TOTAL</label></td>
            </tr>
            <?php $__currentLoopData = $detalleVentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalleVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalleVenta->stock_producto_id); ?></td>
                    <td><?php echo e($detalleVenta->descripcion_producto); ?></td>
                    <td><?php echo e($detalleVenta->cantidad); ?></td>
                    <td><?php echo e($detalleVenta->kilos); ?></td>
                    <td><?php echo e($detalleVenta->precio); ?></td>
                    <td><?php echo e(($detalleVenta->precio * $detalleVenta->cantidad)); ?></td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <table class="table table-condensed table-bordered">
            <tr>
                <td><label for="">SUB TOTAL:</label></td><td><?php echo e(number_format($venta->total - $venta->igv,2)); ?></td>
            </tr>
            <tr>
                <td><label for="">IGV</label></td><td><?php echo e($venta->igv); ?></td>
            </tr>
            <tr>
                <td><label for="">TOTAL</label></td><td><?php echo e($venta->total); ?></td>
            </tr>
            <tr>
                <td><label for="">OBSERVACIÓN</label></td><td><?php echo e($venta->observacion); ?></td>
            </tr>
            <tr>
                <td><label for="">SON:</label></td><td><?php echo e($venta->monto_descripcion); ?></td>
            </tr>
        </table>


        
            
                
                    
                        
                        
                        
                        
                    
                    
                    
                
            
        
    </div>
</div>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
</body>
</html>

<?php $__env->startSection('header','Áreas'); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('area.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('area.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <a href="<?php echo e(route('area.nuevo')); ?>" class="btn btn-success">NUEVA ÁREA</a>
            </div>
        </div>
        <div class="col-md-10">
            <form action="" class="form-inline">
                
                
            </form>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <table class="table table-hover table-condensed box">
                <thead>
                <th>DESCRIPCION</th>
                <th>ACCIONES</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(strtoupper($area->descripcion)); ?></td>
                        <td>
                            
                            <a href="#" class="btn btn-xs btn-warning edit"  value="<?php echo e($area->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                            <?php echo e(csrf_field()); ?>

                            <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($area->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($areas->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/area.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
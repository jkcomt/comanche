<?php $__env->startSection('content'); ?>
    <div class="panel panel-heading">
        <h1 class="panel-title"><strong>Bienvenid@ <?php echo e(auth()->user()->personal->nombres); ?></strong></h1>

    </div>
    <div class="panel panel-body">
        <h1 class="text-center">SISTEMA COMANCHE</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>CAMPAÑA</th>
        <th>FECHA - HORA</th>
        <th>N° GUÍA</th>
        <th>AGRICULTOR\CLIENTE</th>
        <th>VARIEDAD</th>
        <th>N° SACOS RECEP.</th>
        <th>N° SACOS A SECAR</th>
        <th>ESTADO</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $loteSecados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loteSecado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loteSecado->lote->compania); ?></td>
                <td><?php echo e($loteSecado->lote->fecha.' '.Carbon\Carbon::parse($loteSecado->lote->hora)->format('H:i:s A')); ?></td>
                <td><?php echo e($loteSecado->lote->nro_guia); ?></td>
                <?php if($loteSecado->lote->cliente): ?>
                    <td><?php echo e($loteSecado->lote->cliente->apellidos); ?> <?php echo e($loteSecado->lote->cliente->nombres); ?></td>
                <?php elseif($loteSecado->lote->agricultor): ?>
                    <td><?php echo e($loteSecado->lote->agricultor->apellidos); ?> <?php echo e($loteSecado->lote->agricultor->nombres); ?></td>
                <?php endif; ?>
                <td><?php echo e($loteSecado->lote->variedad->descripcion); ?></td>
                <td><?php echo e($loteSecado->lote->nro_sacos); ?></td>
                <td><?php echo e($loteSecado->lote->nro_humedad_mayor_13); ?></td>
                <td>
                    <span style="font-size: 10px;" class="<?php if($loteSecado->estado_secado == 'terminado'): ?> label label-success <?php else: ?> label label-warning <?php endif; ?>"><?php echo e(ucwords($loteSecado->estado_secado)); ?></span>
                </td>
                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($loteSecado->lote->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>

                    <a href="<?php if(!$loteSecado->accionesDisponibles()): ?> # <?php else: ?> <?php echo e(route('tendido.index',['id'=>$loteSecado->id])); ?><?php endif; ?>" class="btn btn-xs btn-primary" <?php if(!$loteSecado->accionesDisponibles()): ?> disabled <?php endif; ?>><span class="glyphicon glyphicon-list-alt"></span> LIST. TENDIDOS</a>

                    <a href="<?php if($loteSecado->estado_secado == 'terminado'): ?> # <?php elseif(!$loteSecado->accionesDisponibles()): ?> # <?php else: ?> <?php echo e(route('tendido.nuevo',['id'=>$loteSecado->id])); ?> <?php endif; ?>" <?php if($loteSecado->estado_secado == 'terminado'): ?> disabled <?php elseif(!$loteSecado->accionesDisponibles()): ?> disabled <?php endif; ?> class="btn btn-xs btn-success"><span class="glyphicon glyphicon-plus"></span> TENDIDO</a>
                    
                    
                    <?php echo e(csrf_field()); ?>

                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($loteSecados->links()); ?>

</div>
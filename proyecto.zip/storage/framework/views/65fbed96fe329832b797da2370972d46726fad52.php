<?php $__env->startSection('api'); ?>
    <?php echo $__env->make('apis.select2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <button class="btn btn-sm btn-primary" id="create-agri">Insertar otro registro</button>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('lote.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('clientes.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('agricultor.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('variedad.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('procedencia.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('chofer.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('vehiculo.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header','Recepción de lotes ingresantes'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
                <div id="msg-error" class="alert alert-danger" style="display:none;">
                    <strong>Corriga los campos indicados por favor.</strong>
                    <ul>
                    <div id="listaerrores">
                    </div>
                    </ul>
                    
                    
                        
                    
                    
                </div>
            <div class="panel panel-default">
                <form action="<?php echo e(route('lote.create')); ?>" id="registrarLote">
                    <?php echo e(csrf_field()); ?>

                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label for="campania" class="control-label">Campaña:</label>
                                <input type="text" value="2018" class="form-control" name="campania">
                            </div>
                            <div class="col-md-2">
                                <label for="" class="control-label">Nro. Guía:</label>
                                <input type="text" value="<?php if(isset($lote)): ?><?php echo e($lote->generarSerieGuia()); ?><?php else: ?> <?php echo e("REC-000001"); ?><?php endif; ?>" class="form-control" readonly name="nro_guia">
                            </div>
                            <div class="col-md-4">
                                <label for="" class="control-label">Fecha - Hora:</label>
                                <div class="form-inline">
                                    <div class="form-group">
                                        <input type="date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>" class="form-control" name="fecha">
                                        <input type="time" value="<?php echo e(\Carbon\Carbon::now()->toTimeString()); ?>" class="form-control" name="hora">
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-4" id="grupoCliente">
                                <div class="radio-inline">
                                    <label for="control-label"><input type="radio" checked name="optradio" value="agricultor"> Agricultor</label>
                                </div>
                                <div class="radio-inline">
                                    <label for="control-label"><input type="radio" name="optradio" value="cliente"> Cliente</label>
                                </div>
                                <div class="input-group" id="agricultorGroup">
                                    <select name="agricultor" id="agricultor" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $agricultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $agricultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($agricultor); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addAgricultor"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadAgricultor" url="<?php echo e(route('lote.agricultores')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                                <div class="input-group" id="clienteGroup">
                                    <select name="cliente" id="cliente" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($cliente); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addCliente"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadCliente" url="<?php echo e(route('lote.clientes')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4" id="grupoVariedad">
                                <label for="" class="control-label">Variedad:</label>
                                <div class="input-group">
                                    <select name="variedad" id="variedad" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $variedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($variedad); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addVariedad"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadVariedad" url="<?php echo e(route('lote.variedades')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="">
                                    <label for="">Tipo Peso</label>
                                    <div class="center-block" style="">
                                    <label class="radio-inline">
                                        <input type="radio" name="rbtipoPeso" checked id="radioPeso" value="sacos"> Sacos
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="rbtipoPeso" id="radioPeso" value="kilos"> Kilos
                                    </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="sacos-grupo">
                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Nro. Sacos</label>
                                        <input type="number" class="form-control" name="nro_sacos" min="0" value="0">
                                    </div>
                                    </div>
                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Kilos:</label>
                                        <input type="number" class="form-control" name="kilos" step="any" min="0" value="0">
                                    </div>
                                    </div>
                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Peso Real(Kg):</label>
                                        <input type="number" class="form-control" name="pesoreal" readonly step="2" min="0" value="0">
                                    </div>
                                    </div>
                                </div>
                                <div class="kilos-grupo">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Peso Real(Kg)</label>
                                            <input type="number" class="form-control" name="kilos_pesoreal" value="" step="any" min="0" value="0">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Nro. Sacos</label>
                                            <input type="number" class="form-control" name="kilos_nro_sacos" min="0" value="0">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Kilos:</label>
                                            <input type="number" class="form-control" name="kilos_kilos" readonly step="any" min="0" value="0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4" id="grupoProcedencia">
                                <label for="" class="control-label">Origen:</label>
                                <div class="input-group">
                                    <select name="procedencia" id="procedencia" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $procedencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $procedencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($procedencia); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addProcedencia"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadProcedencia" url="<?php echo e(route('lote.procedencias')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="">Tipo de flete:</label><br>
                                <label class="radio-inline">
                                    <input type="radio" checked name="rbtipoflete" id="fleteSaco" value="fleteSaco"> Saco
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="rbtipoflete" id="fleteSaco" value="fletePeso"> Peso
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="rbtipoflete" id="fleteSaco" value="fleteTonelada"> Tonelada
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label for="">Pagado por:</label><br>
                                <label class="radio-inline">
                                    <input type="radio" name="pagadopor" id="pagadoporCliente" checked value="Agricultor">
                                    <label for="pagadoporCliente">Agricultor\Cliente</label>
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="pagadopor" id="pagadoporMolino" value="Molino">
                                    <label for="pagadoporMolino">Molino</label>
                                </label>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="">Flete x Saco:</label>
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1">S/</span>
                                    <input type="number" value="0" class="form-control" name="fletexSaco" step="any" min="0">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Flete x Peso:</label>
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1">S/</span>
                                    <input type="number" value="0" class="form-control" name="fletexPeso" step="any" min="0">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Flete x Tonelada:</label>
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1">S/</span>
                                    <input type="number" value="0" class="form-control" name="fletexTonelada" step="any" min="0">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Flete Total:</label>
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1">S/</span>
                                    <input type="number" value="0" class="form-control" name="fletexTotal" readonly step="any" min="0">
                                </div>
                            </div>

                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4" id="grupoChofer">
                                <label for="chofer" class="control-label">Chofer:</label>
                                <div class="input-group">
                                    <select name="chofer" id="chofer" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chofer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($chofer); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addChofer"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadChofer" url="<?php echo e(route('lote.choferes')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4" id="grupoVehiculo">
                                <label for="vehiculo" class="control-label">Vehículo:</label>
                                <div class="input-group">
                                    <select name="vehiculo" id="vehiculo" class="form-control" >
                                        
                                        <option></option>
                                        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($vehiculo); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addVehiculo"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadVehiculo" url="<?php echo e(route('lote.vehiculos')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="">Nro Sacos % humedad > 13:</label>
                                <input type="number" value="0" class="form-control" name="nro_sacos_mayor_13" min="0">
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Condición:</label>
                                <input type="text" value="Vacío" class="form-control" readonly name="condicion_mayor_13">
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Nro Sacos % humedad <= 13:</label>
                                <input type="number" value="0" class="form-control" name="nro_sacos_menor_13" min="0">
                            </div>
                            <div class="col-md-3">
                                <label for="" class="">Condición:</label>
                                <input type="text" value="Vacío" class="form-control" readonly name="condicion_menor_13">
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                            <label for="" >Observación:</label>
                            <textarea id="" cols="30" rows="5" class="form-control" name="observacion"></textarea>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success">Registrar</button>
                                <button class="btn btn-default" type="reset" id="limpiar">Limpiar</button>
                                <a href="<?php echo e(route('lote.index')); ?>" class="btn btn-warning " id="index">Volver</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/lote.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
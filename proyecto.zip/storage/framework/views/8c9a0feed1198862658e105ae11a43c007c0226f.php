<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N°.GUÍA</th>
        <th>FECHA-HORA</th>
        <th>PERSONA/EMPRESA</th>
        <th>ESTADO</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $liquidaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liquidacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($liquidacion->estado == 'Habilitado'): ?>
                <tr>
                    <td><?php echo e($liquidacion->serie_liquidacion); ?></td>
                    <td><?php echo e($liquidacion->fecha_registro); ?></td>
                    <td>
                        <?php if($liquidacion->lote->agricultor_id): ?>
                            <?php echo e($liquidacion->lote->agricultor->apellidos.' '.$liquidacion->lote->agricultor->nombres); ?>

                        <?php elseif($liquidacion->lote->empresa_id): ?>
                            <?php echo e($liquidacion->lote->empresa->razon_social); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($liquidacion->lote->produccionIngresoNoConforme() && $liquidacion->lote->loteSecadoNoConforme()): ?>
                            <?php if($liquidacion->lote->stockResultadoProduccionNoConforme()): ?>
                                <label class="label label-success">TERMINADO</label>
                                <?php else: ?>
                                <label class="label label-warning">EN PROCESO</label>
                            <?php endif; ?>
                        <?php else: ?>
                            <label class="label label-warning">EN PROCESO</label>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($liquidacion->lote->produccionIngresoNoConforme() && $liquidacion->lote->loteSecadoNoConforme()): ?>
                            <?php if($liquidacion->lote->stockResultadoProduccionNoConforme()): ?>
                                <a href="<?php echo e(route('liquidacion.reporte',$liquidacion->id)); ?>" target="_blank" class="btn btn-xs btn-info"><span class="glyphicon glyphicon-print"></span> IMP.</a>
                            <?php else: ?>
                                <a href="#" target="_blank" class="btn btn-xs btn-info disabled"><span class="glyphicon glyphicon-print"></span> IMP.</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="#" target="_blank" class="btn btn-xs btn-info disabled"><span class="glyphicon glyphicon-print"></span> IMP.</a>
                        <?php endif; ?>
                        <?php echo e(csrf_field()); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($liquidaciones->links()); ?>

</div>
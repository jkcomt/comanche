<?php $__env->startSection('header','Variedad de Cáscara'); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('variedad.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('variedad.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <a href="<?php echo e(route('variedad.nuevo')); ?>" class="btn btn-success">NUEVA VARIEDAD</a>
            </div>
        </div>
        <div class="col-md-10">
            <form action="" class="form-inline text-right">
                <input type="text" id="buscarVariedad" placeholder="BUSCAR..." class="form-control">
                
            </form>
        </div>
    </div>
    <br>
    <div class="row" id="tabla">
        <?php echo $__env->make('variedad.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/variedad.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
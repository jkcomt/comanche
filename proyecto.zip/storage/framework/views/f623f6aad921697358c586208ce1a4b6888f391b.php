<div class="col-lg-12 col-md-12 col-sm-12 table-responsive">
    <table class="table table-hover table-condensed small box">
        <thead>
        <th>CAMPAÑA</th>
        <th>FECHA - HORA</th>
        <th>N° GUÍA</th>
        <th>AGRI.\EMP.</th>
        <th>VARIEDAD</th>
        <th>N° SACOS RECEP.</th>
        <th>N° SACOS A SECAR</th>
        <th>N° SACOS OBTE.</th>
        <th>CONFORME</th>
        <th>ESTADO</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $loteSecados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loteSecado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loteSecado->lote->compania); ?></td>
                <td><?php echo e($loteSecado->fecha); ?> <?php echo e(Carbon\Carbon::parse($loteSecado->hora)->format('H:i A')); ?></td>
                <td><?php echo e($loteSecado->nro_serie_guia); ?></td>
                <?php if($loteSecado->lote->agricultor): ?>
                    <td><?php echo e($loteSecado->lote->agricultor->apellidos); ?> <?php echo e($loteSecado->lote->agricultor->nombres); ?></td>
                <?php elseif($loteSecado->lote->empresa): ?>
                    <td><?php echo e($loteSecado->lote->empresa->razon_social); ?></td>
                <?php endif; ?>
                <td><?php echo e($loteSecado->lote->variedad->descripcion); ?></td>
                <td><?php echo e($loteSecado->lote->nro_sacos); ?></td>
                <td><?php echo e($loteSecado->lote->nro_humedad_mayor_13); ?></td>
                <td>
                    <?php if($loteSecado->estado_secado == 'terminado'): ?>
                        <?php echo e($loteSecado->sumtatotalnrosacosrecogidos()); ?>

                    <?php else: ?>
                        <span style="font-size: 10px;" class="label label-warning"><?php echo e(ucwords("En proceso")); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if(!$loteSecado->tendido->isEmpty()): ?>
                        <?php if($loteSecado->tendido->where('estado','Habilitado')->last()->ultimoNroSacosNoRecogidos() and $loteSecado->estado_secado == 'terminado'): ?>
                        <a href="#" class="btn btn-xs btn-primary <?php if($loteSecado->conforme): ?>  <?php else: ?> conformidad <?php endif; ?>" loteSecado="<?php echo e($loteSecado->id); ?>" <?php if($loteSecado->conforme): ?> disabled <?php endif; ?>><?php if($loteSecado->conforme): ?> SI <?php else: ?> NO <?php endif; ?></a>
                        <?php else: ?>
                            <span style="font-size: 10px;" class="label label-warning"><?php echo e(ucwords("En proceso")); ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span style="font-size: 10px;" class="label label-warning"><?php echo e(ucwords("En proceso")); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <span style="font-size: 10px;" class="<?php if($loteSecado->estado_secado == 'terminado'): ?> label label-success <?php else: ?> label label-warning <?php endif; ?>"><?php echo e(ucwords($loteSecado->estado_secado)); ?></span>
                </td>

                <td>
                    <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($loteSecado->lote->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                    <a href="<?php echo e(route('secado.reporte',['id'=>$loteSecado->id])); ?>" target="_blank" class="btn btn-xs btn-info
                        <?php if($loteSecado->estado_secado == 'terminado'): ?>
                        <?php else: ?>
                            disabled
                        <?php endif; ?>
                    "><span class="glyphicon glyphicon-print"></span> IMP.</a>
                    <a href="<?php if(!$loteSecado->accionesDisponibles()): ?> # <?php else: ?> <?php echo e(route('tendido.index',['id'=>$loteSecado->id])); ?><?php endif; ?>" class="btn btn-xs btn-primary" <?php if(!$loteSecado->accionesDisponibles()): ?> disabled <?php endif; ?>><span class="glyphicon glyphicon-list-alt"></span> TEND.</a>
                    
                    
                    
                    
                    <?php echo e(csrf_field()); ?>

                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($loteSecados->links()); ?>

</div>

<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-hover table-condensed box">
        <thead>
        <th>NICK</th>
        
        <th>AREA</th>
        <th>APELLIDOS Y NOMBRES</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->name); ?></td>
                
                <td><?php echo e(ucfirst($usuario->area->descripcion)); ?></td>
                <td><?php echo e($usuario->personal->apellidos.' '.$usuario->personal->nombres); ?></td>
                <td>
                    
                    <a href="#" class="btn btn-xs btn-warning edit"  value="<?php echo e($usuario->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($usuario->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($usuarios->links()); ?>

</div>
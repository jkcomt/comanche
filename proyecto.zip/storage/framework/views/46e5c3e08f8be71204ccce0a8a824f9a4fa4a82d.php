<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-footer'); ?>
    <button class="btn btn-sm btn-primary" id="create-agri">Insertar otro registro</button>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('agricultor.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','Nuevo Agricultor '); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
                <div id="msg-error" class="alert alert-danger" style="display:none;">
                    <strong>Corriga los campos indicados por favor.</strong>
                    
                    
                        
                    
                    
                </div>
            <form action="<?php echo e(route('agricultor.create')); ?>" method="POST" id="registrarAgricultor">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-6">
                   <label for="" class="control-label">Apellidos :</label>
                   <input type="text" class=" form-control" name="apellidos" value="<?php echo e(old('apellido')); ?>" onkeypress="return lettersOnly(event)" maxlength="20">
                </div>
                <div class="form-group col-md-6">
                   <label for="nombres" class="control-label">Nombres :</label>
                   <input type="text" class="form-control" name="nombres" value="<?php echo e(old('nombres')); ?>" onkeypress="return lettersOnly(event)" maxlength="20">
                </div>

                <div class="form-group col-md-6">
                    <label for="dni" class="control-label">DNI :</label>
                    <input type="text" maxlength="8" class=" form-control" name="dni" value="<?php echo e(old('dni')); ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                </div>

                <div class="form-group col-md-6">
                    <label for="ruc" class="control-label">RUC :</label>
                    <input type="text" class="form-control" name="ruc" value="<?php echo e(old('ruc')); ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57' maxlength="12">
                </div>
                <div class="form-group col-md-6">
                    <label for="celular" class="control-label">Celular :</label>
                    <input type="number" class="form-control" name="celular" value="<?php echo e(old('celular')); ?>" maxlength="12">
                </div>

                <div class="form-group col-md-6">
                    <label for="" class="control-label">Dirección :</label>
                    <input type="text" class=" form-control" name="direccion" value="<?php echo e(old('direccion')); ?>" maxlength="20">
                </div>
                <div class="form-group col-md-6">
                    <label for="email" class="control-label">E-mail :</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" maxlength="20">
                </div>


                <div class="form-group col-md-12">
                    <button class="btn btn-success">Registrar</button>
                    <button class="btn btn-default" type="reset" id="limpiar">Limpiar</button>
                    <a href="<?php echo e(route('agricultor.index')); ?>" class="btn btn-warning " id="index">Volver</a>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/agricultor.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
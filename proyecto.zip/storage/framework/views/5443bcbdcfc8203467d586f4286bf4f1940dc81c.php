<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>N°.GUÍA</th>
        <th>FECHA-HORA</th>
        <th>PERSONA/EMPRESA</th>
        <th>COMPROBANTE</th>
        <th>N°.COMPROBANTE</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($venta->estado == 'Habilitado'): ?>
                <tr>
                    <td><?php echo e($venta->nro_guia_venta); ?></td>
                    <td><?php echo e($venta->fecha_venta); ?> <?php echo e(Carbon\Carbon::parse($venta->hora_venta)->format('H:i:s A')); ?></td>
                    <td>
                        <?php if($venta->comprador_persona_id): ?>
                            <?php echo e($venta->compradorPersona->apellidos.' '.$venta->compradorPersona->nombres); ?>

                        <?php elseif($venta->comprador_empresa_id): ?>
                            <?php echo e($venta->compradorEmpresa->razon_social); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($venta->tipo_comprobante); ?></td>
                    <td>
                        <?php switch($venta->tipo_comprobante):
                            case ('BOLETA'): ?>
                                <?php echo e($venta->nro_boleta); ?>

                                <?php break; ?>
                            <?php case ('FACTURA'): ?>
                                <?php echo e($venta->nro_factura); ?>

                                <?php break; ?>
                            <?php case ('TICKET'): ?>
                                <?php echo e($venta->nro_ticket); ?>

                            <?php break; ?>
                        <?php endswitch; ?>
                    </td>
                    <td>
                        <a href="#" class="btn btn-xs btn-default detalle" value="<?php echo e($venta->id); ?>" id="<?php echo e($venta->id); ?>"><span class="glyphicon glyphicon-info-sign"></span> DET.</a>
                        <a href="<?php echo e(route('ventas.reporte',$venta->id)); ?>" target="_blank" class="btn btn-xs btn-info"><span class="glyphicon glyphicon-print"></span> IMP.</a>
                        <a href="<?php echo e(route('ventas.edit',$venta->id)); ?>" class="btn btn-xs btn-warning edit"  value="<?php echo e($venta->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                        <?php echo e(csrf_field()); ?>

                        <?php if(auth()->user()->area->descripcion == 'administrador'): ?>
                            <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($venta->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($ventas->links()); ?>

</div>

<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema Comanche</title>

    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('img/logo.ico/apple-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('img/logo.ico//apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('img/logo.ico//apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/logo.ico/apple-icon-76x76.')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('img/logo.ico/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('img/logo.ico/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('img/logo.ico/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('img/logo.ico/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/logo.ico/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset('img/logo.ico//android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('img/logo.ico/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('img/logo.ico/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/logo.ico/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('img/logo.ico//manifest.json')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('img/logo.ico/ms-icon-144x144.png')); ?>">
    <meta name="theme-color" content="#ffffff">


    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(asset('css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect. -->
    <link rel="stylesheet" href="<?php echo e(asset('css/skins/skin-blue.min.css')); ?>">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Google Font -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

    <?php echo $__env->yieldContent('api'); ?>

    <style>
        .skin-blue .main-header .logo{
            background-color: white;
            color:black;
        }

        .skin-blue .main-header .logo:hover{
            background-color: white !important;
            color:black !important;
        }
    </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to get the
desired effect
|---------------------------------------------------------|
| SKINS         | skin-blue                               |
|               | skin-black                              |
|               | skin-purple                             |
|               | skin-yellow                             |
|               | skin-red                                |
|               | skin-green                              |
|---------------------------------------------------------|
|LAYOUT OPTIONS | fixed                                   |
|               | layout-boxed                            |
|               | layout-top-nav                          |
|               | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition skin-blue sidebar-mini">
<?php echo $__env->make('mensajes.exito', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('mensajes.confirmacion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(Request::is('lote') || Request::is('secado') ): ?>
    <style>
        input[readonly]{
            background-color:transparent;
            border: 0;
            font-size: 1em;
        }

    </style>
    <?php echo $__env->make('lote.modals.detalle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php echo $__env->yieldContent('modal'); ?>
<div class="wrapper">

    <!-- Main Header -->
    <header class="main-header">

        <!-- Logo -->
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            
            <span class="logo-mini"><b><img src="<?php echo e(asset('img/logo.jpg')); ?>" width="100%" alt=""></b></span>
            <!-- logo for regular state and mobile devices -->
            
            <span class="logo-lg"><b><img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="25%"> COMANCHE</b></span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <!-- Navbar Right Menu -->
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->

                    <!-- Notifications Menu -->
                    
                        
                        
                            
                            
                        
                        
                            
                            
                                
                                
                                    
                                        
                                            
                                        
                                    
                                    
                                
                            
                            
                        
                    

                    <!-- User Account Menu -->
                    <li class="dropdown notificaciones"  >
                        

                            
                            
                                
                                
                            
                        
                        
                        <?php echo $__env->make('notificaciones.notificaciones', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                    </li>
                    <li class="dropdown">
                        <!-- Menu Toggle Button -->
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <!-- The user image in the navbar-->
                            <!-- hidden-xs hides the username on small devices so only the image appears. -->
                            <span class="glyphicon glyphicon-user"></span>
                            <span class="hidden-xs"><?php echo e(auth()->user()->personal->apellidos.' '.auth()->user()->personal->nombres); ?></span>
                            <span class="caret"></span>
                        </a>
                        <?php if(auth()->check()): ?>
                            <ul class="dropdown-menu" role="menu">
                                <!-- Menu Footer-->
                                <form action="<?php echo e(route('logout')); ?>" method="post" class="" style="margin-bottom:0px;">
                                    <?php echo e(csrf_field()); ?>

                                <li class="">
                                    <div class="">
                                            <button class="btn btn-danger btn-flat btn-block">Cerrar Sesión</button>
                                    </div>
                                </li>
                                </form>
                            </ul>
                        <?php endif; ?>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    
                        
                    
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

            <!-- Sidebar Menu -->
            <ul class="sidebar-menu" data-widget="tree">
                <li class="header">OPCIONES</li>
                <!-- Optionally, you can add icons to the links -->
                <li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-home"></i> <span>Principal</span></a></li>
               <?php if(auth()->user()->area->descripcion != 'secado'): ?>
                <li class="<?php if(Request::is('agricultor')): ?> active <?php elseif(Request::is('agricultor/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('agricultor.index')); ?>"><i class="fa fa-user-circle"></i> <span>Agricultores</span></a></li>
                <li class="<?php if(Request::is('cliente')): ?> active <?php elseif(Request::is('cliente/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('cliente.index')); ?>"><i class="fa fa-user-circle-o"></i> <span>Clientes</span></a></li>
                <li class="<?php if(Request::is('variedad')): ?> active <?php elseif(Request::is('variedad/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('variedad.index')); ?>"><i class="fa fa-list"></i> <span>Variedades</span></a></li>
                    <li class="<?php if(Request::is('procedencia')): ?> active <?php elseif(Request::is('procedencia/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('procedencia.index')); ?>"><i class="fa fa-map-marker"></i> <span>Procedencia</span></a></li>
                <li class="<?php if(Request::is('chofer')): ?> active <?php elseif(Request::is('chofer/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('chofer.index')); ?>"><i class="fa fa-id-card-o"></i> <span>Choferes</span></a></li>
                <li class="<?php if(Request::is('vehiculo')): ?> active <?php elseif(Request::is('vehiculo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('vehiculo.index')); ?>"><i class="fa fa-truck"></i> <span>Vehículos</span></a></li>
                <li class="<?php if(Request::is('lote')): ?> active <?php elseif(Request::is('lote/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('lote.index')); ?>"><i class="fa fa-th"></i> <span>Recepción</span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->area->descripcion != 'recepcion'): ?>
                <li class="<?php if(Request::is('secado')): ?> active <?php elseif(Request::is('tendido/*')): ?> active <?php elseif(Request::is('recojo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('secado.index')); ?>"><i class="fa fa-sun-o"></i> <span>Secado</span></a></li>
                <li class="<?php if(Request::is('responsable')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('responsable.index')); ?>"><i class="fa fa-address-card"></i> <span>Responsables</span></a></li>
                <li class="<?php if(Request::is('almacen')): ?> active <?php elseif(Request::is('almacen/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('almacen.index')); ?>"><i class="fa fa fa-archive"></i> <span>Almacen</span></a></li>
                <li class="<?php if(Request::is('configuracion')): ?> active <?php elseif(Request::is('configuracion/*')): ?> active <?php elseif(Request::is('usuario')): ?> active <?php elseif(Request::is('usuario/*')): ?> active <?php elseif(Request::is('personal/*')): ?> active <?php elseif(Request::is('personal')): ?> active <?php elseif(Request::is('area')): ?> active <?php elseif(Request::is('area/*')): ?> active  <?php endif; ?> "><a href="<?php echo e(route('configuracion')); ?>"><i class="fa fa-cog"></i> <span>Configuración</span></a></li>
                <?php endif; ?>
                
                    
                        
                
              
                    
                    
                        
                        
                    
                
            </ul>
            <!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1 class="page-header">
                <?php echo $__env->yieldContent('header'); ?>
                <?php echo $__env->yieldSection(); ?>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content container-fluid">

            <!--------------------------
              | Your Page Content Here |
              -------------------------->
            
                <?php echo $__env->yieldContent('content'); ?>
            
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    
        
        
            
        
        
        
    

    <!-- Control Sidebar -->
    
        
        
            
            
        
        
        
            
            
                
                
                    
                        
                            

                            
                                

                                
                            
                        
                    
                
                

                
                
                    
                        
                            
                                
                                
                    
                  
                            

                            
                                
                            
                        
                    
                
                

            
            
            
            
            
            
            
                
                    

                    
                        
                            
                            
                        

                        
                            
                        
                    
                    
                
            
            
        
    
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
    immediately after the control sidebar -->
    
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<!-- Bootstrap 3.3.7 -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/notificaciones.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>
<?php $__env->startSection('header','Configuración'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row text-center">
        <?php if(auth()->user()->area->descripcion == 'administrador'): ?>
        <div class="col-lg-2" >
            <a href="<?php echo e(route('usuario.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-users"></span></h3> <strong>Usuarios</strong></a>
        </div>
        <div class="col-lg-2">
            <a href="<?php echo e(route('personal.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-user"></span></h3> <strong>Personal</strong></a>
        </div>
        <div class="col-lg-2">
            <a href="<?php echo e(route('area.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-cubes"></span></h3> <strong>Áreas</strong></a>
        </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
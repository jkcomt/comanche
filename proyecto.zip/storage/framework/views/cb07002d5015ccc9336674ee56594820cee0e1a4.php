<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE SALIDAS DE PRODUCCIÓN '.$ingresoProduccion->nro_guia_ingreso); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('nuevaproduccion.index',['id'=>$ingresoProduccion->id])); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('nuevaproduccion.modals.detalle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-1">
            <a class="btn btn-warning" href="<?php echo e(route('produccion.index')); ?>">Volver</a>
        </div>
        <div class="col-md-2">
            <div class="form-group form-inline">
                <a href="<?php echo e(route('nuevaproduccion.nuevo',['id'=>$ingresoProduccion->id])); ?>" class="btn btn-success <?php if($ingresoProduccion->nro_sacos_ingresados <= $ingresoProduccion->nuevaProduccion->where('estado','Habilitado')->sum('nro_sacos_a_procesar')): ?> disabled <?php endif; ?>" >NUEVA PRODUCCIÓN</a>
            </div>
        </div>
        <div class="col-md-9">
            <form action="" class="form-inline text-right">
                <label for="" class="control-label">Nro. Guía : </label>
                <input type="text" id="buscarNuevaPro" placeholder="BUSCAR..." class="form-control">
                <input type="hidden" name="idIngresoProduccion" value="<?php echo e($ingresoProduccion->id); ?>" id="idIngresoProduccion">
                
            </form>
        </div>
    </div>
    <br>
    
        
            

            
        
    
    
        
    
    <div class="row" id="tabla2">
        <?php echo $__env->make('nuevaproduccion.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <script src="<?php echo e(asset('js/nuevaproduccion.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
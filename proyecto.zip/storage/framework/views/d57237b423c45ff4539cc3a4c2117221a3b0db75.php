<?php $__env->startSection('api'); ?>
    <?php echo $__env->make('apis.select2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style>
        .vertical-align {
            display: flex;
            align-items: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    
    <a class="btn btn-sm btn-warning"
       href="">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea registrar la venta?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-success confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning" data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    
    <?php echo $__env->make('comprador_persona.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('comprador_empresa.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header','Nueva Venta'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div id="msg-error" class="alert alert-danger" style="display:none;">
                <strong>Corriga los campos indicados por favor.</strong>
                <ul>
                    <div id="listaerrores">
                    </div>
                </ul>
            </div>
            <form action="<?php echo e(route('ventas.create')); ?>" id="registrarVenta">
                <div class="panel panel-default">
                    <div class="panel-heading">INFORMACIÓN DE VENTA</div>
                    <div class="panel-body">

                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="nro_guia_nueva_produccion">Guía Prod:</label>
                                            <input type="text" name="nro_guia_venta" class="form-control"
                                                   readonly
                                                   value="<?php if(isset($venta)): ?><?php echo e($venta->generarSerieVenta()); ?><?php else: ?><?php echo e("VENT-000001"); ?><?php endif; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="fecha">Fecha - Hora:</label>
                                            <div class="form-inline">
                                                <div class="form-group">
                                                    <input type="date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>"
                                                           class="form-control" name="fecha">
                                                    <input type="time" value="<?php echo e(\Carbon\Carbon::now()->toTimeString()); ?>"
                                                           class="form-control" name="hora">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4" id="grupoCliente">
                                        <div class="radio-inline">
                                            <label for="control-label"><input type="radio" checked name="optradio" value="persona" id="rbAgri"> Persona</label>
                                        </div>
                                        <div class="radio-inline">
                                            <label for="control-label"><input type="radio" name="optradio" value="empresa" id="rbEmp"> Empresa</label>
                                        </div>
                                        <div class="input-group" id="agricultorGroup">
                                            <select name="agricultor" id="agricultor" class="form-control" >
                                                
                                                <option></option>
                                                <?php $__currentLoopData = $agricultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $agricultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($agricultor); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addAgricultor"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadAgricultor" url="<?php echo e(route('ventas.agricultores')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                        </div>
                                        <div class="input-group" id="empresaGroup">
                                            <select name="empresa" id="empresa" class="form-control" >
                                                
                                                <option></option>
                                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($empresa); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="input-group-btn">
                                        <a href="#" class="btn btn-primary" type="button" id="addEmpresa"><span class="glyphicon glyphicon-plus"></span></a>
                                        <a href="#" class="btn btn-warning" type="button" id="reloadEmpresa" url="<?php echo e(route('ventas.empresas')); ?>"><span class="glyphicon glyphicon-refresh"></span></a>
                                    </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="tipo_comprobante">Comprobante:</label>
                                            <select name="tipo_comprobante" id="tipoComprobante" class="form-control">
                                                <option value="" selected="selected">Seleccione tipo de comprobante</option>
                                                <option value="BOLETA">BOLETA</option>
                                                <option value="FACTURA">FACTURA</option>
                                                <option value="TICKET">TICKET</option>
                                            </select>
                                            
                                                   
                                                   
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="serie_comprobante">Nro. Comprobante:</label>
                                            <input type="text" name="serie_comprobante" class="form-control"
                                                   readonly
                                                   value="">
                                        </div>
                                    </div>
                                </div>



                            </div>

                        </div>

                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">Producto</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label for="producto">Descrip. Producto</label>
                                        <select name="producto" id="producto" class="form-control input-sm">
                                            <option value="">SELECCIONE UN PRODUCTO</option>
                                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->descripcion_producto); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        </select>
                                    </div>
                                    <div class="col-md-2 form-group">
                                        <label for="nro_sacos">Cant. Stock</label>
                                        <input type="number" class="form-control input-sm" name="cantidad_stock" value="0" readonly>
                                    </div>
                                    <div class="col-md-2 form-group">
                                        <label for="sacos_kilos">Kilos</label>
                                        <input type="number" class="form-control input-sm" name="sacos_kilos" value="0" step="any" readonly>
                                    </div>
                                    <div class="col-md-2 form-group">
                                        <label for="precio_maquila">Precio</label>
                                        <div class="input-group">
                                            <div class="input-group-addon">S/</div>
                                            <input type="number" readonly class="form-control input-sm" name="precio" value="0" step="any">
                                        </div>
                                    </div>
                                    <div class="col-md-2 form-group">
                                        <label for="cantidad">Cant. Comprar</label>
                                        <input type="number" class="form-control input-sm" name="cantidad" value="0">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary btn-block" name="add">
                                    <h4><span class="fa fa-plus-circle"></span></h4>
                                    <span>AÑADIR</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-responsive table-hover table-condensed small box text-center " id="tabla">
                            <thead >
                            <tr>
                                <th>COD. PRODUCTO</th>
                                <th>DESCRIPCIÓN DE PRODUCTO</th>
                                <th>CANTIDAD</th>
                                <th>KILOS</th>
                                <th>PRECIO</th>
                                <th>TOTAL</th>
                                <th>OPCIONES</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row form-group">
                            <div class="col-md-2">
                                <label for="" class="label-control">SUB TOTAL</label>
                            </div>
                            <div class="col-md-2">
                                <div class="input-group">
                                    <div class="input-group-addon">S/</div>
                                    <input type="text" class="form-control input-sm" name="sub_total" value="0.00" readonly/>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-2">
                                <label for="" class="label-control">IGV</label>
                            </div>
                            <div class="col-md-2">
                                <div class="input-group">
                                    <div class="input-group-addon">S/</div>
                                <input type="text" class="form-control input-sm" name="igv" value="0.00" readonly/>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-2">
                                <label for="" class="label-control">TOTAL</label>
                            </div>
                            <div class="col-md-2">
                                <div class="input-group">
                                    <div class="input-group-addon">S/</div>
                                    <input type="text" class="form-control input-sm" name="total" value="0.00" readonly/>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-2">
                                <label for="" class="label-control">OBSERVACIÓN</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control input-sm" name="observacion" class="form-control"  maxlength="12"/>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-2">
                                <label for="" class="label-control">SON:</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control input-sm" name="monto_descripcion" class="form-control"  maxlength="50"/>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success registarVenta" type="button">Registrar</button>
                                <a href="<?php echo e(route('ventas.index')); ?>"
                                   class="btn btn-warning">Volver</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/ventas.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
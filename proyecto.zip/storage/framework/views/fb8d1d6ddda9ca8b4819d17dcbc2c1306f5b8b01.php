﻿
<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE TENDIDOS DE LOTE '.$loteSecado->lote->nro_guia ); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('tendido.index',['id'=>$loteSecado->id])); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tendido.modals.detalle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-1">
            <a class="btn btn-warning" href="<?php echo e(route('secado.index')); ?>">Volver</a>
        </div>
        <div class="col-md-2">
            <div class="form-group form-inline">

                <a href="<?php if(!$loteSecado->tendido->isEmpty() && $loteSecado->lote->nro_humedad_mayor_13 == $loteSecado->tendido->where('estado','Habilitado')->sum('nro_sacos_a_secar')): ?>#<?php else: ?> <?php echo e(route('tendido.nuevo',['id'=>$loteSecado->id])); ?><?php endif; ?>  "class="btn btn-success" <?php if($loteSecado->lote->nro_humedad_mayor_13 > $loteSecado->tendido->where('estado','Habilitado')->sum('nro_sacos_a_secar')): ?><?php else: ?> disabled <?php endif; ?>>NUEVO TENDIDO</a>
            </div>
        </div>
        <div class="col-md-9">
            <form action="" class="form-inline text-right">
                <input type="text" id="buscarTendido" placeholder="BUSCAR..." class="form-control">
                <input type="hidden" name="idlote" value="<?php echo e($loteSecado->id); ?>">
                
            </form>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-body">
                <strong><p style="font-size: 15px;">Nro. sacos enviados a secar: <?php echo e($loteSecado->lote->nro_humedad_mayor_13); ?></p></strong>
                <?php $resultado = 0;
                  $resultado1 = 0;
                ?>
                <?php $__currentLoopData = $loteSecado->tendido->where('estado','Habilitado'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tendido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $resultado += ($tendido->recojo->where('estado','Habilitado')->sum('nro_sacos_recogidos'));
                    $resultado1 += ($tendido->nro_sacos_a_secar);
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$loteSecado->tendido->isEmpty()): ?>
                    <?php if($loteSecado->tendido->where('estado','Habilitado')->last()->recojo->where('estado','Habilitado')->last()): ?>
                        <?php if($loteSecado->tendido->last()->recojo->last()->nro_sacos_no_recogidos == 0): ?>
                            <?php if(($resultado1 - $resultado) > 0): ?>
                                <strong><p style="font-size: 15px;">Total de Nro. de sacos perdidos: <?php echo e($resultado1 - $resultado); ?></p></strong>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row" id="tabla">
        <?php echo $__env->make('tendido.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/tendido.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
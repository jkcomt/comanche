<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-footer'); ?>
    <button class="btn btn-sm btn-primary" id="create-agri">Insertar otro registro</button>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('almacen.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','Nuevo Almacen'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
                <div id="msg-error" class="alert alert-danger" style="display:none;">
                    <strong>Corriga los campos indicados por favor.</strong>
                    
                    
                        
                    
                    
                </div>
            <form action="<?php echo e(route('almacen.create')); ?>" method="POST" id="registrarAlmacen">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-6 ">
                   <label for="nombre" class="control-label">Nombre :</label>
                   <input type="text" class=" form-control" name="nombre" value="<?php echo e(old('nombre')); ?>">
                </div>


                <div class="form-group col-md-12">
                    <button class="btn btn-success">Registrar</button>
                    <button class="btn btn-default" type="reset" id="limpiar">Limpiar</button>
                    <a href="<?php echo e(route('almacen.index')); ?>" class="btn btn-warning " id="index">Volver</a>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/almacen.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
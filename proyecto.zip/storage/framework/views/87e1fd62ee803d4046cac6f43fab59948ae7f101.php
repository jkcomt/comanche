
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Sistema Comanche</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo e(asset('css/ie10-viewport-bug-workaround.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->




<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="<?php echo e(asset('js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <script src="<?php echo e(asset('js/ie-emulation-modes-warning.js')); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body{
            font-size: 12px;
        }
        .center-text{
            text-align: center;
        }
        .padding-top{
            padding-top: 30px;
            border: hidden;
        }

    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <table>
            <tr>
                <td style="padding-right: 100px">
                    <h5>MOLINO EL COMANCHE S.R.L.</h5>
                    <h5>Carretera Panamericana Norte Km. 690 Centro Poblado Menor San Martín de Porres – San José – Provincia de Pacasmayo – La Libertad.</h5>
                    <h5>RUC: 20482126112  |  Cel: 972620212  |  Teléfono:044-498067</h5>
                </td >
                <td>
                    
                    <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" width="120px" height="100px">
                </td>
            </tr>
        </table>
    </div>
    <hr>
    <div class="text-center">
        <h3 style="margin-top:5px;">DOCUMENTO DE LIQUIDACION</h3>
    </div>
    <div class="">
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Campaña</td>
                    <td>Nro. Guía</td>
                    <td>Fecha - Hora</td>
                    <td>
                        <?php if(!empty($liquidacion->lote->agricultor)): ?>
                            Agricultor
                        <?php elseif(!empty($liquidacion->lote->cliente)): ?>
                            Cliente
                        <?php else: ?>
                            Empresa
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->compania); ?>

                    </td>
                    <td><?php echo e($liquidacion->lote->nro_guia); ?>

                    </td>
                    <td>
                        <?php echo e($liquidacion->lote->fecha.' '.Carbon\Carbon::parse($liquidacion->lote->hora)->format('H:i:s A')); ?>

                    </td>
                    <td>
                        <?php if(!empty($liquidacion->lote->agricultor)): ?>
                            <?php echo e($liquidacion->lote->agricultor->apellidos.' '.$liquidacion->lote->agricultor->nombres); ?>

                        <?php elseif(!empty($liquidacion->lote->cliente)): ?>
                            <?php echo e($liquidacion->lote->cliente->apellidos.' '.$liquidacion->lote->cliente->nombres); ?>

                        <?php else: ?>
                            <?php echo e($liquidacion->lote->empresa->razon_social); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>

        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Variedad de cáscara</td>
                    
                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            Kilos
                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            Nro. Sacos
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            Nro. Sacos
                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            Peso Real(Kg)
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            Peso Real(Kg)
                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            Kilos
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->variedad->descripcion); ?>

                    </td>
                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            <?php echo e($liquidacion->lote->nro_sacos); ?>

                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            <?php echo e($liquidacion->lote->peso_real); ?>

                        <?php endif; ?>
                    </td>
                    
                        
                    

                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            <?php echo e($liquidacion->lote->kilos); ?>

                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            <?php echo e($liquidacion->lote->nro_sacos); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($liquidacion->lote->tipo_peso == 'sacos'): ?>
                            <?php echo e($liquidacion->lote->peso_real); ?>

                        <?php elseif($liquidacion->lote->tipo_peso == 'kilos'): ?>
                            <?php echo e($liquidacion->lote->kilos); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Origen</td>
                    <td>Tipo flete</td>
                    <td>
                        Pagado por
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->procedencia->lugar); ?>

                    </td>
                    <td>
                        <?php if($liquidacion->lote->tipo_flete == 'fletePeso'): ?>
                            Peso
                        <?php elseif($liquidacion->lote->tipo_flete == 'fleteSaco'): ?>
                            Saco
                        <?php elseif($liquidacion->lote->tipo_flete == 'fleteTonelada'): ?>
                            Tonelada
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e(ucfirst($liquidacion->lote->pagado_por)); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Chofer</td>
                    <td>Vehículo</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->chofer->apellidos.' '.$liquidacion->lote->chofer->nombres); ?>

                    </td>
                    <td>
                        <?php echo e($liquidacion->lote->vehiculo->marca.' '.$liquidacion->lote->vehiculo->descripcion.' '.$liquidacion->lote->vehiculo->placa); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="">
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Nro Sacos % humedad mayor a 13 </td>
                    <td>Condición</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->nro_humedad_mayor_13); ?>

                    </td>
                    <td>
                        <?php if($liquidacion->lote->nro_humedad_mayor_13 > 0): ?> Secado <?php else: ?> Vacío <?php endif; ?>
                    </td>
                </tr>

            </table>
            <table class="table table-condensed table-bordered">
                <tr>
                    <td>Nro Sacos % humedad menor e igual a 13 </td>
                    <td>Condición</td>
                </tr>
                <tr>
                    <td>
                        <?php echo e($liquidacion->lote->nro_humedad_menor_13); ?>

                    </td>
                    <td>
                        <?php if($liquidacion->lote->nro_humedad_menor_13 > 0): ?> Producción <?php else: ?> Vacío <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
        <?php if($liquidacion->lote->loteSecado): ?>
            <h5>INFORMACIÓN DE SECADO</h5>
            <table class="table table-condensed table-bordered">
                <tr>
                    <td><strong>Nro Sacos Entrantes:</strong></td>
                    <td><strong>Nro Sacos Secos:</strong></td>
                    <td><strong>Nro Pérdida de Sacos :</strong></td>
                    <td><strong>Importe Total de Transferencia a Almacen:</strong></td>
                </tr>
                <tr>
                    <td><?php echo e($liquidacion->lote->loteSecado->lote->nro_humedad_mayor_13); ?></td>
                    <td><?php echo e($liquidacion->lote->loteSecado->sumtatotalnrosacosrecogidos()); ?></td>
                    <td>
                        <?php $resultado = 0;
                        $resultado1 = 0;
                        $kilosperdidos = 0;
                        ?>
                        <?php $__currentLoopData = $liquidacion->lote->loteSecado->tendido->where('estado','Habilitado'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tendido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $resultado += ($tendido->recojo->where('estado','Habilitado')->sum('nro_sacos_recogidos'));
                                $resultado1 += ($tendido->nro_sacos_a_secar);
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($resultado1 - $resultado); ?>

                    </td>
                    <td class="text-right">
                        <?php $resultado = 0;
                        ?>
                        <?php if($liquidacion->lote->loteSecado): ?>
                        <?php $__currentLoopData = $liquidacion->lote->loteSecado->tendido->where('estado','Habilitado'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tendido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $resultado += ($tendido->totalImporteAlmacen());
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php echo e(number_format($resultado,2)); ?>

                    </td>
                </tr>
            </table>
        <?php endif; ?>

        <h5>INFORMACIÓN DE PRODUCCION</h5>

        <?php $__currentLoopData = $liquidacion->lote->produccionIngreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produccionIngreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <table class="table table-condensed table-bordered">
                    <tr>
                        <td colspan="5"><strong>N° GUIA PRODUCCIÓN</strong></td>
                        <td colspan="6"><?php echo e($produccionIngreso->nro_guia_ingreso); ?></td>
                    </tr>

                

                    <?php $__currentLoopData = $produccionIngreso->nuevaProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nuevaProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5"><strong>N° GUÍA SALIDA</strong></td>
                            <td colspan="6">
                                <?php echo e($nuevaProduccion->nro_guia_salida); ?>

                            </td>
                        </tr>

                
                
                
                    <tr rowspan="2">
                        <td rowspan="2"><strong>PRODUCTO</strong></td>
                        <td rowspan="2"><strong>N° SACOS</strong></td>
                        <td rowspan="2"><strong>KILOS</strong></td>
                        <td rowspan="2"><strong>PRECIO MAQUILA</strong></td>
                        <td rowspan="2"><strong>N° ENVASES</strong></td>
                        <td rowspan="2"><strong>ENVASES</strong></td>
                        <td rowspan="2"><strong>PRECIO ENVASE</strong></td>
                        <td rowspan="2"><strong>ADICIONAL X SACO</strong></td>
                        <td colspan="3"><strong>SUB TOTAL</strong></td>

                    </tr>
                    <tr>
                        <td><strong>MAQUILA</strong></td>
                        <td><strong>ENVASES</strong></td>
                        <td><strong>ADICIONAL</strong></td>
                    </tr>
                    <?php $__currentLoopData = $nuevaProduccion->resultadoProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadoProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($resultadoProduccion->producto); ?></td>
                            <td><?php echo e($resultadoProduccion->nro_sacos); ?></td>
                            <td><?php echo e($resultadoProduccion->kilos); ?></td>
                            <td><?php echo e($resultadoProduccion->precio_maquila); ?></td>
                            <td><?php echo e($resultadoProduccion->nro_envases); ?></td>
                            <td><?php echo e($resultadoProduccion->envase); ?></td>
                            <td><?php echo e($resultadoProduccion->precio_envase); ?></td>
                            <td><?php echo e(number_format($resultadoProduccion->sub_total_adicional/$resultadoProduccion->nro_sacos,2)); ?></td>
                            <td><?php echo e($resultadoProduccion->sub_total_maquila); ?></td>
                            <td><?php echo e($resultadoProduccion->sub_total_envase); ?></td>
                            <td><?php echo e($resultadoProduccion->sub_total_adicional); ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr>
                            <td colspan="8"><strong>PRODUCCIÓN (MAQUILA)</strong></td>
                            <td colspan="3">S/ <?php echo e($nuevaProduccion->resultadoProduccion->sum('sub_total_maquila')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="8"><strong>ENVASES</strong></td>
                            <td colspan="3">S/ <?php echo e($nuevaProduccion->resultadoProduccion->sum('sub_total_envase')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="8"><strong>ADICIONAL</strong></td>
                            <td colspan="3">S/ <?php echo e($nuevaProduccion->resultadoProduccion->sum('sub_total_adicional')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="8"><strong>TOTAL A FAVOR DEL MOLINO</strong></td>
                            <td colspan="3">S/ <?php echo e($nuevaProduccion->resultadoProduccion->sum('sub_total_maquila') + $nuevaProduccion->resultadoProduccion->sum('sub_total_envase')+ $nuevaProduccion->resultadoProduccion->sum('sub_total_adicional')); ?></td>
                        </tr>
                    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <h5>INFORMACIÓN DE VENTAS</h5>
        <table class="table table-condensed table-bordered">
            <tr>
                <td><strong>PRODUCTO</strong></td>
                <td><strong>CANTIDAD</strong></td>
                <td><strong>KILOS</strong></td>
                <td><strong>PRECIO</strong></td>
                <td><strong>TOTAL</strong></td>
            </tr>
                <?php $__currentLoopData = $detalleVentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalleVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($detalleVenta->descripcion_producto); ?></td>
                        <td><?php echo e($detalleVenta->cantidad); ?></td>
                        <td><?php echo e($detalleVenta->kilos); ?></td>
                        <td><?php echo e($detalleVenta->precio); ?></td>
                        <td><?php echo e($detalleVenta->total); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
             $suma = 0;
            ?>
            <?php $__currentLoopData = $liquidacion->lote->stockResultadoProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockResultadoProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $stockResultadoProduccion->DetalleVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalleVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($suma += ($detalleVenta->cantidad * $detalleVenta->precio)); ?>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4" class="text-right"><strong>INCLUYE IGV</strong></td>
                <td><?php echo e(number_format($suma,2)); ?></td>
            </tr>
        </table>
        <h5>LIQUIDACIÓN</h5>
        <table class="table table-condensed table-bordered">
            <tr>
                <td><strong>VENTAS</strong></td><td><?php echo e(number_format($suma,2)); ?></td>
            </tr>
            <tr>
                <?php if($liquidacion->lote->pagado_por == "agricultor" || $liquidacion->lote->pagado_por == "empresa"): ?>
                    <td><strong>PRESTAMO DEL MOLINO</strong></td><td>0.00</td>
                <?php else: ?>
                    <td><strong>PRESTAMO DEL MOLINO</strong></td><td><?php echo e(number_format($liquidacion->lote->flete_total,2)); ?></td>
                <?php endif; ?>
            </tr>
            <tr>
                <?php
                    $sumaAlmacen = 0;
                    $sumaMolino = 0;
                ?>
                <?php if($liquidacion->lote->loteSecado): ?>
                <?php $__currentLoopData = $liquidacion->lote->loteSecado->tendido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tendido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $tendido->recojo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recojo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($sumaAlmacen += $recojo->importe_sacos); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <td><strong>COBROS TRANSFERENCIA</strong></td><td><?php echo e(number_format($sumaAlmacen,2)); ?></td>
                <?php $__currentLoopData = $liquidacion->lote->produccionIngreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produccionIngreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $produccionIngreso->nuevaProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nuevaProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $nuevaProduccion->resultadoProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadoProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($sumaMolino += $resultadoProduccion->sub_total_maquila + $resultadoProduccion->sub_total_envase + $resultadoProduccion->sub_total_adicional); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
            <tr>
                <td><strong>A FAVOR DEL MOLINO</strong></td>
                <td><?php echo e(number_format($sumaMolino,2)); ?></td>
            </tr>
            <tr>
                <td><strong>TOTAL</strong></td>
                <?php if($liquidacion->lote->pagado_por == "agricultor" || $liquidacion->lote->pagado_por == "empresa"): ?>
                    <td><?php echo e(number_format($suma-0-$sumaAlmacen-$sumaMolino,2)); ?></td>
                <?php else: ?>
                    <td><?php echo e(number_format($suma-$liquidacion->lote->flete_total-$sumaAlmacen-$sumaMolino,2)); ?></td>
                <?php endif; ?>

            </tr>
        </table>
        <table class="table padding-top">
            <tr class="center-text" >
                <td>
                    <b>___________________________________</b><br>
                    <b>Administrador</b><br>
                    
                </td>
                <td>
                </td>
                <td>
                    <b>___________________________________</b><br>
                    <?php if(!empty($liquidacion->lote->agricultor)): ?>
                        <b>Agricultor :</b>
                        <b><?php echo e($liquidacion->lote->agricultor->apellidos.' '.$liquidacion->lote->agricultor->nombres); ?></b><br>
                        <b>
                            <?php if(isset($liquidacion->lote->agricultor->dni)): ?>
                                DNI: <?php echo e($liquidacion->lote->agricultor->dni); ?>

                                <?php else: ?>
                                    RUC: <?php echo e($liquidacion->lote->agricultor->ruc); ?>

                                    <?php endif; ?>
                        </b>
                    <?php elseif(!empty($liquidacion->lote->cliente)): ?>
                        <b>Cliente :</b>
                        <b><?php echo e($liquidacion->lote->cliente->apellidos.' '.$liquidacion->lote->cliente->nombres); ?></b><br>
                        <b><?php echo e($liquidacion->lote->cliente->dni); ?></b>
                    <?php elseif(!empty($liquidacion->lote->empresa)): ?>
                        <b>Representante : <?php echo e($liquidacion->lote->empresa->representante); ?></b><br>
                        <b>          DNI : <?php echo e($liquidacion->lote->empresa->dni_representante); ?></b>

                    <?php endif; ?>
                </td>
            </tr>

        </table>
    </div>
</div>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
</body>
</html>

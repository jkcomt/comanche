<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        
        <?php if(auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">OPCIONES</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-home"></i> <span>Principal</span></a></li>
            <?php if(auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
                <li class="treeview">
                    <a href="#"><i class="fa fa fa-th"></i> <span>Recepción</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php if(Request::is('agricultor')): ?> active <?php elseif(Request::is('agricultor/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('agricultor.index')); ?>"><i class="fa fa-user-circle-o"></i> <span>Agricultores</span></a></li>
                        
                        <li class="<?php if(Request::is('empresa')): ?> active <?php elseif(Request::is('empresa/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('empresa.index')); ?>"><i class="fa fa fa-building"></i> <span>Empresas</span></a></li>
                        <li class="<?php if(Request::is('variedad')): ?> active <?php elseif(Request::is('variedad/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('variedad.index')); ?>"><i class="fa fa-list"></i> <span>Variedades de Cáscara</span></a></li>
                        <li class="<?php if(Request::is('procedencia')): ?> active <?php elseif(Request::is('procedencia/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('procedencia.index')); ?>"><i class="fa fa-map-marker"></i> <span>Procedencia</span></a></li>
                        <li class="<?php if(Request::is('chofer')): ?> active <?php elseif(Request::is('chofer/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('chofer.index')); ?>"><i class="fa fa-id-card-o"></i> <span>Choferes</span></a></li>
                        <li class="<?php if(Request::is('vehiculo')): ?> active <?php elseif(Request::is('vehiculo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('vehiculo.index')); ?>"><i class="fa fa-truck"></i> <span>Vehículos</span></a></li>
                        <li class="<?php if(Request::is('lote')): ?> active <?php elseif(Request::is('lote/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('lote.index')); ?>"><i class="fa fa-th"></i> <span>Recepción</span></a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#"><i class="fa fa fa-sun-o"></i> <span>Secado</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(auth()->user()->area->descripcion == 'secado' || auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
                            <li class="<?php if(Request::is('secado')): ?> active <?php elseif(Request::is('tendido/*')): ?> active <?php elseif(Request::is('recojo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('secado.index')); ?>"><i class="fa fa-sun-o"></i> <span>Secado</span></a></li>
                            <li class="<?php if(Request::is('responsable')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('responsable.index')); ?>"><i class="fa fa-address-card"></i> <span> Resp. de Cuadrilla</span></a></li>
                            
                        <?php endif; ?>
                    </ul>
                </li>

                <?php if(auth()->user()->area->descripcion == 'produccion' || auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
                    <li class="<?php if(Request::is('produccion_ingreso')): ?> active <?php elseif(Request::is('produccion_ingreso/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('produccion.index')); ?>"><i class="fa fa-bullseye"></i> <span>Producción</span></a></li>
                <?php endif; ?>
                <li class="treeview">
                    <a href="#"><i class="fa fa fa-usd"></i> <span>Ventas</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(auth()->user()->area->descripcion == 'ventas' || auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
                            
                            <li class="<?php if(Request::is('stock_producto')): ?> active <?php elseif(Request::is('stock_producto/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('stock_producto.index')); ?>"><i class="fa fa-archive"></i> <span> Stock de Productos</span></a></li>
                            <li class="<?php if(Request::is('comprador_persona')): ?> active <?php elseif(Request::is('comprador_persona/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('comprador_persona.index')); ?>"><i class="fa fa-user-circle-o"></i> <span> Comprador Persona</span></a></li>
                            <li class="<?php if(Request::is('comprador_empresa')): ?> active <?php elseif(Request::is('comprador_empresa/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('comprador_empresa.index')); ?>"><i class="fa fa-building"></i> <span> Comprador Empresa</span></a></li>
                            <li class="<?php if(Request::is('ventas')): ?> active <?php elseif(Request::is('ventas/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('ventas.index')); ?>"><i class="fa fa fa-usd"></i> <span> Registro de Venta</span></a></li>
                            <li class="<?php if(Request::is('liquidacion')): ?> active <?php elseif(Request::is('liquidacion/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('liquidacion.index')); ?>"><i class="fa fa-download"></i> <span> Liquidaciones</span></a></li>
                            
                        <?php endif; ?>
                    </ul>
                </li>
                <?php if(auth()->user()->area->descripcion == 'administrador' || auth()->user()->area->descripcion == 'gerencia'): ?>
                    <li class="<?php if(Request::is('configuracion')): ?> active <?php elseif(Request::is('configuracion/*')): ?> active <?php elseif(Request::is('usuario')): ?> active <?php elseif(Request::is('usuario/*')): ?> active <?php elseif(Request::is('personal/*')): ?> active <?php elseif(Request::is('personal')): ?> active <?php elseif(Request::is('area')): ?> active <?php elseif(Request::is('area/*')): ?> active  <?php endif; ?> "><a href="<?php echo e(route('configuracion')); ?>"><i class="fa fa-cog"></i> <span>Configuración</span></a></li>
                <?php endif; ?>
            <?php endif; ?>


        </ul>
        <?php else: ?>
        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">OPCIONES</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-home"></i> <span>Principal</span></a></li>
            <?php if(auth()->user()->area->descripcion == 'recepcion' ): ?>
                <li class="<?php if(Request::is('agricultor')): ?> active <?php elseif(Request::is('agricultor/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('agricultor.index')); ?>"><i class="fa fa-user-circle-o"></i> <span>Agricultores</span></a></li>
                <li class="<?php if(Request::is('empresa')): ?> active <?php elseif(Request::is('empresa/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('empresa.index')); ?>"><i class="fa fa-user-circle-o"></i> <span>Empresas</span></a></li>
                <li class="<?php if(Request::is('variedad')): ?> active <?php elseif(Request::is('variedad/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('variedad.index')); ?>"><i class="fa fa-list"></i> <span>Variedades de Cáscara</span></a></li>
                <li class="<?php if(Request::is('procedencia')): ?> active <?php elseif(Request::is('procedencia/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('procedencia.index')); ?>"><i class="fa fa-map-marker"></i> <span>Procedencia</span></a></li>
                <li class="<?php if(Request::is('chofer')): ?> active <?php elseif(Request::is('chofer/*')): ?> active <?php endif; ?> "><a href="<?php echo e(route('chofer.index')); ?>"><i class="fa fa-id-card-o"></i> <span>Choferes</span></a></li>
                <li class="<?php if(Request::is('vehiculo')): ?> active <?php elseif(Request::is('vehiculo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('vehiculo.index')); ?>"><i class="fa fa-truck"></i> <span>Vehículos</span></a></li>
                <li class="<?php if(Request::is('lote')): ?> active <?php elseif(Request::is('lote/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('lote.index')); ?>"><i class="fa fa-th"></i> <span>Recepción</span></a></li>
            <?php endif; ?>
            <?php if(auth()->user()->area->descripcion == 'secado' ): ?>
                <li class="<?php if(Request::is('secado')): ?> active <?php elseif(Request::is('tendido/*')): ?> active <?php elseif(Request::is('recojo/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('secado.index')); ?>"><i class="fa fa-sun-o"></i> <span>Secado</span></a></li>
                <li class="<?php if(Request::is('responsable')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('responsable.index')); ?>"><i class="fa fa-address-card"></i> <span> Resp. de Cuadrilla</span></a></li>
                
            <?php endif; ?>
            <?php if(auth()->user()->area->descripcion == 'produccion'): ?>
                <li class="<?php if(Request::is('produccion_ingreso')): ?> active <?php elseif(Request::is('produccion_ingreso/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('produccion.index')); ?>"><i class="fa fa-bullseye"></i> <span>Producción</span></a></li>
            <?php endif; ?>

            
                <?php if(auth()->user()->area->descripcion == 'ventas'): ?>
                    
                    <li class="<?php if(Request::is('stock_producto')): ?> active <?php elseif(Request::is('stock_producto/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('stock_producto.index')); ?>"><i class="fa fa-archive"></i> <span> Stock de Productos</span></a></li>
                    <li class="<?php if(Request::is('comprador_persona')): ?> active <?php elseif(Request::is('comprador_persona/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('comprador_persona.index')); ?>"><i class="fa fa-user-circle-o"></i> <span> Comprador Persona</span></a></li>
                    <li class="<?php if(Request::is('comprador_empresa')): ?> active <?php elseif(Request::is('comprador_empresa/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('comprador_empresa.index')); ?>"><i class="fa fa-building"></i> <span> Comprador Empresa</span></a></li>
                    <li class="<?php if(Request::is('ventas')): ?> active <?php elseif(Request::is('ventas/*')): ?> active <?php elseif(Request::is('responsable/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('ventas.index')); ?>"><i class="fa fa fa-usd"></i> <span> Registro de Venta</span></a></li>
                    <li class="<?php if(Request::is('liquidacion')): ?> active <?php elseif(Request::is('liquidacion/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('liquidacion.index')); ?>"><i class="fa fa-download"></i> <span> Liquidaciones</span></a></li>
                    
                <?php endif; ?>

        </ul>
        <?php endif; ?>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

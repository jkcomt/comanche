<div class="modal fade" tabindex="-1" role="dialog" id="modal-produccion-detalle">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detalle</h4>
            </div>
            <div class="modal-body">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div id="msg-error" class="alert alert-danger" style="display:none;">
                <strong>Corriga los campos indicados por favor.</strong>
                <ul>
                    <div id="listaerrores">
                    </div>
                </ul>
                
                
                
                
                
            </div>
            <div class="">
                <form action="" id="detalleLote">
                    <?php echo e(csrf_field()); ?>

                    <div class="">

                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label for="campania" class="control-label">Campaña:</label>
                                <input type="text" value="2018" class="form-control" name="campania" readonly>
                            </div>
                            <div class="col-md-3">
                                <label for="" class="control-label">Nro. Guía Ingreso a Produccion:</label>
                                <input type="text" value="" class="form-control" readonly name="nro_guia_ingreso">
                                
                                
                            </div>
                            <div class="col-md-3">
                                <label for="" class="control-label">Fecha - Hora Ingreso:</label>
                                <input type="datetime" value="" class="form-control" name="fecha_ingreso" readonly>
                                
                                
                            </div>
                            

                                
                                    
                                        
                                    
                                    
                                
                            
                        </div>
                        <div class="row">
                            <div class="col-md-4 form-group" id="grupoVariedad">
                                <label for="" class="control-label">Nro. Guía Recepción:</label>
                                <input type="text" value="" class="form-control" readonly name="nro_guia">
                                
                                
                                    
                                
                            </div>
                            <div class="col-md-4">
                                <label for="" class="control-label">Fecha - Hora Recepción:</label>
                                <input type="datetime" value="" class="form-control" name="fecha" readonly>
                            </div>
                            <div class="col-md-4" id="grupoCliente">

                                <div class="" id="agricultorGroup">
                                    <label class="control-label" name="lblCliente">
                                    Agricultor
                                    </label>
                                    <input type="text" class=" form-control" id="clienteAgricultor" value="" readonly>
                                </div>
                            </div>
                            
                                
                                    
                                    
                                        
                                            
                                            
                                        
                                        
                                        
                                        
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    

                                
                            
                            
                                
                                
                            
                            
                                
                                
                                    
                                
                            
                        </div>
                        <div class="row">
                                <div class="sacos-grupo">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="" name="">Nro. Sacos Ingresantes:</label>
                                            <input type="number" class="form-control" name="nro_sacos_ingreso" min="0" value="0" readonly >
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="" name="">Kilos Totales por Sacos:</label>
                                            <input type="number" class="form-control" name="kilos_totales_ingreso" min="0" value="0" readonly >
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="" name="">Área de Origen:</label>
                                            <input type="text" class="form-control" name="area_origen" readonly >
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="" name="">Variedad de Cáscara:</label>
                                            <input type="text" class=" form-control" id="variedad" value="" readonly>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 text-right">
                                <button class="btn btn-warning " id="index" data-dismiss="modal">Volver</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
</div>
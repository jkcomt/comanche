<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-hover table-condensed box">
        <thead>
        <th>NOMBRES Y APELLIDOS</th>
        <th>DNI</th>
        <th>CELULAR</th>
        <th>DIRECCIÓN</th>
        <th>EMAIL</th>
        <th>ACCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $personales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($personal->nombres.' '.$personal->apellidos); ?></td>
                <td><?php echo e($personal->dni); ?></td>
                <td><?php echo e($personal->celular); ?></td>
                <td><?php echo e($personal->direccion); ?></td>
                <td><?php echo e($personal->email); ?></td>
                <td>
                    
                    <a href="#" class="btn btn-xs btn-warning edit"  value="<?php echo e($personal->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDIT.</a>
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($personal->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIM.</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($personales->links()); ?>

</div>
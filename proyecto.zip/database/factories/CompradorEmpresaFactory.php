<?php

use Faker\Generator as Faker;

$factory->define(App\CompradorEmpresa::class, function (Faker $faker) {
    return [
        //
    ];
});

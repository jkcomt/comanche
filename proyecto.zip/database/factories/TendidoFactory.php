<?php

use Faker\Generator as Faker;

$factory->define(App\Tendido::class, function (Faker $faker) {
    return [
        //
    ];
});

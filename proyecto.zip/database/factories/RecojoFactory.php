<?php

use Faker\Generator as Faker;

$factory->define(App\Recojo::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

use Faker\Generator as Faker;

$factory->define(App\CompradorAgricultor::class, function (Faker $faker) {
    return [
        //
    ];
});

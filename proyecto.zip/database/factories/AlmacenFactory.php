<?php

use Faker\Generator as Faker;

$factory->define(App\Almacen::class, function (Faker $faker) {
    return [

    ];
});

<?php

use Faker\Generator as Faker;

$factory->define(App\ProduccionIngreso::class, function (Faker $faker) {
    return [
        //
    ];
});

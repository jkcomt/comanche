<?php

use Faker\Generator as Faker;

$factory->define(App\Ventas::class, function (Faker $faker) {
    return [
        //
    ];
});

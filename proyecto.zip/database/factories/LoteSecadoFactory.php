<?php

use Faker\Generator as Faker;

$factory->define(App\LoteSecado::class, function (Faker $faker) {
    return [
        //
    ];
});

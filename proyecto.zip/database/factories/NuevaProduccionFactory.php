<?php

use Faker\Generator as Faker;

$factory->define(App\NuevaProduccion::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

use Faker\Generator as Faker;

$factory->define(App\StockProductoItem::class, function (Faker $faker) {
    return [
        //
    ];
});
